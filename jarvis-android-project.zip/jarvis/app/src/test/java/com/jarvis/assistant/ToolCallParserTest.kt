package com.jarvis.assistant

import com.jarvis.assistant.ai.ParsedToolCall
import com.jarvis.assistant.ai.ToolCallParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ToolCallParserTest {
    @Test fun parsesWellFormedCall() {
        val call = ToolCallParser.parse("""<tool_call>{"name": "flashlight", "arguments": {"state": "on"}}</tool_call>""")
        assertEquals(ParsedToolCall("flashlight", mapOf("state" to "on")), call)
    }

    @Test fun toleratesMissingClosingTagAndSurroundingProse() {
        val call = ToolCallParser.parse("""Sure. <tool_call>{"name":"device_battery","arguments":{}}""")
        assertEquals(ParsedToolCall("device_battery", emptyMap()), call)
    }

    @Test fun numbersBecomeStrings() {
        val call = ToolCallParser.parse("""<tool_call>{"name":"set_timer","arguments":{"seconds":1200}}</tool_call>""")
        assertEquals(mapOf("seconds" to "1200"), call?.args)
    }

    @Test fun missingArgumentsObjectMeansNoArguments() {
        assertEquals(emptyMap<String, String>(), ToolCallParser.parse("""<tool_call>{"name":"device_info"}</tool_call>""")?.args)
    }

    @Test fun malformedOrAbsentCallsAreIgnored() {
        assertNull(ToolCallParser.parse("<tool_call>{not json}</tool_call>"))
        assertNull(ToolCallParser.parse("""<tool_call>{"arguments":{}}</tool_call>"""))
        assertNull(ToolCallParser.parse("I turned the flashlight on."))
    }
}
