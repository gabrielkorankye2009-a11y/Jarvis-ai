package com.jarvis.assistant

import com.jarvis.assistant.tools.Format
import org.junit.Assert.assertEquals
import org.junit.Test

class FormatTest {
    @Test fun durations() {
        assertEquals("20 minutes", Format.duration(1200))
        assertEquals("1 hour 30 minutes", Format.duration(5400))
        assertEquals("1 minute 1 second", Format.duration(61))
        assertEquals("0 seconds", Format.duration(0))
    }

    @Test fun clock() {
        assertEquals("07:05", Format.clock(7, 5))
        assertEquals("19:30", Format.clock(19, 30))
    }
}
