package com.jarvis.assistant

import com.jarvis.assistant.ai.IntentRouter
import com.jarvis.assistant.ai.RouteOutcome
import org.junit.Assert.assertEquals
import org.junit.Test

class IntentRouterTest {
    private fun command(input: String, tool: String, vararg args: Pair<String, String>) =
        assertEquals("input: $input", RouteOutcome.Command(tool, mapOf(*args)), IntentRouter.route(input))

    private fun clarify(input: String, question: String) =
        assertEquals("input: $input", RouteOutcome.Clarify(question), IntentRouter.route(input))

    private fun noMatch(input: String) = assertEquals("input: $input", RouteOutcome.NoMatch, IntentRouter.route(input))

    @Test fun flashlight() {
        command("Turn on the flashlight", "flashlight", "state" to "on")
        command("turn the torch off please", "flashlight", "state" to "off")
        command("flashlight on", "flashlight", "state" to "on")
        clarify("Turn the flashlight", "Do you want the flashlight on or off?")
        noMatch("how does a flashlight work")
    }

    @Test fun deviceReads() {
        command("What's my battery level?", "device_battery")
        command("how much storage do I have", "device_storage")
        command("about my phone", "device_info")
        command("am I online?", "network_status")
        command("is airplane mode on", "network_status")
        noMatch("write a poem about my dying battery and my feelings about it today")
    }

    @Test fun timers() {
        command("Start a 20 minute timer", "set_timer", "seconds" to "1200")
        command("set a timer for 1 hour 30 minutes", "set_timer", "seconds" to "5400")
        command("20-minute timer", "set_timer", "seconds" to "1200")
        command("set a timer for half an hour", "set_timer", "seconds" to "1800")
        command("set a timer for 1.5 hours", "set_timer", "seconds" to "5400")
        clarify("start a timer", "How long should the timer run?")
        noMatch("how do timers work in swift")
    }

    @Test fun alarmsAskWhenAmbiguous() {
        command("Set an alarm for 7 pm", "set_alarm", "hour" to "19", "minute" to "0")
        command("wake me up at 6:15 am", "set_alarm", "hour" to "6", "minute" to "15")
        command("set an alarm for 19:30", "set_alarm", "hour" to "19", "minute" to "30")
        command("set alarm for 12 am", "set_alarm", "hour" to "0", "minute" to "0")
        clarify("set an alarm for 7", "Do you mean 7:00 AM or PM?")
        clarify("set an alarm", "What time should the alarm ring?")
    }

    @Test fun volume() {
        command("set volume to 40 percent", "set_volume", "percent" to "40")
        command("make the volume 30%", "set_volume", "percent" to "30")
        clarify("turn the volume up", "What volume level, from 0 to 100 percent?")
    }

    @Test fun settingsAndApps() {
        command("open wifi settings", "open_settings", "screen" to "wifi")
        command("bluetooth settings", "open_settings", "screen" to "bluetooth")
        command("open battery saver settings", "open_settings", "screen" to "battery_saver")
        command("open WhatsApp", "open_app", "app_name" to "WhatsApp")
        command("launch the camera app", "open_app", "app_name" to "camera")
        command("open my notes", "open_app", "app_name" to "notes")
        command("Jarvis, please open Maps", "open_app", "app_name" to "Maps")
        noMatch("start a conversation about biology")
    }

    @Test fun clipboard() {
        command("copy hello world to the clipboard", "clipboard_copy", "text" to "hello world")
    }

    @Test fun openConversationFallsThroughToTheModel() {
        noMatch("tell me a joke")
        noMatch("What is the capital of Ghana?")
        noMatch("")
    }
}
