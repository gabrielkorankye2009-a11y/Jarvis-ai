package com.jarvis.assistant

import com.jarvis.assistant.tools.ToolSpecs
import com.jarvis.assistant.tools.ToolValidator
import com.jarvis.assistant.tools.ToolValidator.Validation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolValidatorTest {
    private fun valid(args: Map<String, String>) = Validation.Valid(args)

    @Test fun acceptsValidArguments() {
        assertEquals(valid(mapOf("state" to "on")), ToolValidator.validate(ToolSpecs.flashlight, mapOf("state" to " ON ")))
        assertEquals(valid(mapOf("percent" to "40")), ToolValidator.validate(ToolSpecs.volume, mapOf("percent" to "40.0")))
    }

    @Test fun rejectsMissingOutOfRangeAndWrongTypeArguments() {
        assertTrue(ToolValidator.validate(ToolSpecs.flashlight, emptyMap()) is Validation.Invalid)
        assertTrue(ToolValidator.validate(ToolSpecs.flashlight, mapOf("state" to "sideways")) is Validation.Invalid)
        assertTrue(ToolValidator.validate(ToolSpecs.volume, mapOf("percent" to "500")) is Validation.Invalid)
        assertTrue(ToolValidator.validate(ToolSpecs.volume, mapOf("percent" to "loud")) is Validation.Invalid)
        assertTrue(ToolValidator.validate(ToolSpecs.timer, mapOf("seconds" to "0")) is Validation.Invalid)
        assertTrue(ToolValidator.validate(ToolSpecs.alarm, mapOf("hour" to "24", "minute" to "0")) is Validation.Invalid)
    }

    @Test fun optionalArgumentsMayBeOmittedAndUnknownOnesAreDropped() {
        val result = ToolValidator.validate(ToolSpecs.alarm, mapOf("hour" to "7", "minute" to "5", "rm_rf" to "/"))
        assertEquals(valid(mapOf("hour" to "7", "minute" to "5")), result)
    }

    @Test fun overlongStringsAreRejected() {
        val long = "x".repeat(ToolValidator.MAX_STRING + 1)
        assertTrue(ToolValidator.validate(ToolSpecs.clipboard, mapOf("text" to long)) is Validation.Invalid)
    }

    @Test fun toolNamesAreUnique() {
        assertEquals(ToolSpecs.all.size, ToolSpecs.all.map { it.name }.toSet().size)
    }
}
