package com.jarvis.assistant

import com.jarvis.assistant.registry.CapabilityRegistry
import com.jarvis.assistant.tools.ToolSpecs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Reads the real bundled registry file (the same one the app loads at runtime). */
class CapabilityRegistryFileTest {
    private val registry by lazy { CapabilityRegistry.parse(File("src/main/assets/capability_registry.json").readText()) }

    /** Capabilities implemented by code that is not a tool. Must match tools/registry/status_overrides.txt. */
    private val nonToolCoded = setOf(
        "Natural conversation", "Conversational history", "Command understanding",
        "Intent interpretation", "Question answering", "Model benchmark runner",
    )

    @Test fun hasAtLeast600CapabilitiesAndTheCountFieldIsHonest() {
        assertEquals(registry.count, registry.capabilities.size)
        assertEquals(738, registry.capabilities.size)
    }

    @Test fun twentyDomainsWithAtLeastThirtyEach() {
        val byDomain = registry.capabilities.groupBy { it.domain }
        assertEquals(20, byDomain.size)
        byDomain.forEach { (d, list) -> assertTrue("domain $d has ${list.size}", list.size >= 30) }
    }

    @Test fun idsAndNamesAreUnique() {
        assertEquals(registry.capabilities.size, registry.capabilities.map { it.id }.toSet().size)
        assertEquals(registry.capabilities.size, registry.capabilities.map { it.name.lowercase() }.toSet().size)
    }

    @Test fun everyEntryHasTheRequiredFields() {
        val classes = setOf("FULLY_OFFLINE", "LIMITED_OFFLINE", "ONLINE_REQUIRED", "DEVICE_RESTRICTED")
        registry.capabilities.forEach {
            assertTrue(it.id, it.offlineClass in classes)
            assertTrue(it.id, it.description.isNotBlank() && it.acceptanceTest.isNotBlank() && it.module.isNotBlank())
        }
    }

    @Test fun nothingClaimsToBeTestedOrVerifiedYet() {
        registry.capabilities.forEach {
            assertEquals(it.id, "NOT_TESTED", it.testingStatus)
            assertTrue(it.id, it.implementationStatus in setOf("PLANNED", "IN DEVELOPMENT"))
        }
    }

    @Test fun statusesMatchTheCodeThatActuallyExists() {
        val toolBacked = ToolSpecs.all.flatMap { it.registryNames }.toSet()
        val started = registry.capabilities.filter { it.implementationStatus != "PLANNED" }.map { it.name }.toSet()
        assertEquals(toolBacked + nonToolCoded, started)
    }

    @Test fun everyToolPointsAtARealRegistryEntry() {
        val names = registry.capabilities.map { it.name }.toSet()
        ToolSpecs.all.forEach { spec ->
            spec.registryNames.forEach { assertTrue("${spec.name} -> $it", it in names) }
        }
    }
}
