package com.jarvis.assistant

import com.jarvis.assistant.models.DeviceCapabilities
import com.jarvis.assistant.models.LoadVerdict
import com.jarvis.assistant.models.ModelFile
import com.jarvis.assistant.models.ModelRecommender
import com.jarvis.assistant.models.ProfileTier
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelRecommenderTest {
    private val gb = 1024L * 1024L * 1024L
    private val mb = 1024L * 1024L

    private fun caps(totalGb: Double, availGb: Double = totalGb / 2, freeGb: Double = 20.0, abis: List<String> = listOf("arm64-v8a")) =
        DeviceCapabilities((totalGb * gb).toLong(), (availGb * gb).toLong(), (freeGb * gb).toLong(), abis, 34, 8)

    @Test fun tiersFollowReportedRam() {
        assertEquals(ProfileTier.LITE, ModelRecommender.recommend(caps(3.7)).tier)
        assertEquals(ProfileTier.BALANCED, ModelRecommender.recommend(caps(5.5)).tier)
        assertEquals(ProfileTier.BALANCED, ModelRecommender.recommend(caps(7.3)).tier)
        assertEquals(ProfileTier.ADVANCED, ModelRecommender.recommend(caps(11.0)).tier)
    }

    @Test fun a32BitOnlyDeviceIsAlwaysLite() {
        assertEquals(ProfileTier.LITE, ModelRecommender.recommend(caps(8.0, abis = listOf("armeabi-v7a"))).tier)
    }

    @Test fun suggestedSizeGrowsWithTier() {
        val lite = ModelRecommender.recommend(caps(4.0)).maxModelBytes
        val advanced = ModelRecommender.recommend(caps(12.0)).maxModelBytes
        assertTrue(advanced > lite)
    }

    @Test fun loadVerdicts() {
        assertEquals(LoadVerdict.Ok(null), ModelRecommender.canLoad(1 * gb, caps(8.0, availGb = 4.0)))
        val warned = ModelRecommender.canLoad(2 * gb, caps(8.0, availGb = 1.0))
        assertTrue(warned is LoadVerdict.Ok && warned.warning != null)
        assertTrue(ModelRecommender.canLoad(7 * gb, caps(8.0)) is LoadVerdict.Refuse)
    }

    @Test fun storageCheckKeepsAMargin() {
        assertTrue(ModelRecommender.hasStorageFor(1 * gb, caps(8.0, freeGb = 2.0)))
        assertTrue(!ModelRecommender.hasStorageFor(1 * gb, caps(8.0, freeGb = 1.1)))
    }

    @Test fun rankingPrefersLargestThatFitsThenSmallestOversizedAndSkipsUnsupportedFiles() {
        val device = caps(5.5) // Balanced, suggested limit about 1.9 GB
        val models = listOf(
            ModelFile("tiny.task", 500 * mb),
            ModelFile("mid.task", 1500 * mb),
            ModelFile("huge.task", 4 * gb),
            ModelFile("big.task", 3 * gb),
            ModelFile("notes.txt", 1 * mb),
            ModelFile("other.litertlm", 900 * mb),
        )
        val ranked = ModelRecommender.rankInstalled(models, device, setOf("task", "bin")).map { it.name }
        assertEquals(listOf("mid.task", "tiny.task", "big.task", "huge.task"), ranked)
    }

    @Test fun rankingOfNothingIsEmpty() {
        assertNull(ModelRecommender.rankInstalled(emptyList(), caps(8.0), setOf("task")).firstOrNull())
        assertNotNull(ModelRecommender.rankInstalled(listOf(ModelFile("a.task", mb)), caps(8.0), setOf("task")).firstOrNull())
    }

    @Test fun byteFormatting() {
        assertEquals("1.5 GB", ModelRecommender.formatBytes((1.5 * gb).toLong()))
        assertEquals("512 MB", ModelRecommender.formatBytes(512 * mb))
    }
}
