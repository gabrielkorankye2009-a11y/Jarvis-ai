package com.jarvis.assistant

import com.jarvis.assistant.ai.AssistantEvent
import com.jarvis.assistant.ai.AssistantOrchestrator
import com.jarvis.assistant.ai.ChatTurn
import com.jarvis.assistant.ai.Role
import com.jarvis.assistant.tools.ToolExecutor
import com.jarvis.assistant.tools.ToolRegistry
import com.jarvis.assistant.tools.ToolResult
import com.jarvis.assistant.tools.ToolSpecs
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Tests the orchestration rules with test doubles. They verify routing, validation, confirmation and prompt
 * assembly. They do NOT test language-model quality; see LocalModelEndToEndTest for that.
 */
class AssistantOrchestratorTest {
    private val flashlight = FakeTool(ToolSpecs.flashlight, ToolResult.Success("Flashlight is on."))
    private val volume = FakeTool(ToolSpecs.volume, ToolResult.Success("Volume set."))
    private val clipboard = FakeTool(ToolSpecs.clipboard, ToolResult.Success("Copied."))

    private fun orchestrator(engine: FakeEngine?, error: String = "No model is selected.", tools: List<FakeTool> = listOf(flashlight, volume, clipboard)): AssistantOrchestrator {
        val registry = ToolRegistry(tools)
        return AssistantOrchestrator(registry, ToolExecutor(registry), FakeRunner(engine, error), FakeConfig(), nowText = { "Monday" })
    }

    private fun user(text: String) = listOf(ChatTurn(Role.USER, text))

    @Test fun knownCommandsRunWithNoModelLoaded() = runTest {
        val events = orchestrator(engine = null).handle("flashlight on", user("flashlight on")).toList()
        assertEquals(listOf<AssistantEvent>(AssistantEvent.ToolOutcome("flashlight", ToolResult.Success("Flashlight is on."))), events)
        assertEquals(1, flashlight.calls)
        assertEquals(mapOf("state" to "on"), flashlight.lastArgs)
    }

    @Test fun ambiguousCommandsAskInsteadOfActing() = runTest {
        val events = orchestrator(engine = null).handle("set an alarm for 7", user("set an alarm for 7")).toList()
        assertEquals(listOf<AssistantEvent>(AssistantEvent.Notice("Do you mean 7:00 AM or PM?")), events)
    }

    @Test fun modelToolCallShowsTheRealResultAndDiscardsTheModelsProse() = runTest {
        val failing = FakeTool(ToolSpecs.flashlight, ToolResult.Failure("The camera is busy."))
        val engine = FakeEngine(
            listOf("Sure! I have turned it on. ", """<tool_call>{"name":"flashlight","arguments":{"state":"on"}}</tool_call>"""),
        )
        val events = orchestrator(engine, tools = listOf(failing)).handle("could you light things up", user("could you light things up")).toList()
        assertTrue(events.none { it is AssistantEvent.Final })
        assertEquals(AssistantEvent.ToolOutcome("flashlight", ToolResult.Failure("The camera is busy.")), events.last())
        assertEquals(1, failing.calls)
    }

    @Test fun unknownToolsFromTheModelAreRejected() = runTest {
        val engine = FakeEngine(listOf("""<tool_call>{"name":"delete_everything","arguments":{}}</tool_call>"""))
        val events = orchestrator(engine).handle("wipe it", user("wipe it")).toList()
        val last = events.last() as AssistantEvent.ToolOutcome
        assertTrue(last.result is ToolResult.Failure)
        assertEquals(0, flashlight.calls + volume.calls + clipboard.calls)
    }

    @Test fun invalidModelArgumentsNeverReachTheTool() = runTest {
        val engine = FakeEngine(listOf("""<tool_call>{"name":"set_volume","arguments":{"percent":"500"}}</tool_call>"""))
        val events = orchestrator(engine).handle("louder please maybe", user("louder please maybe")).toList()
        assertTrue((events.last() as AssistantEvent.ToolOutcome).result is ToolResult.Failure)
        assertEquals(0, volume.calls)
    }

    @Test fun confirmationRequiredToolsWaitForTheUser() = runTest {
        val o = orchestrator(engine = null)
        val events = o.handle("copy hi to the clipboard", user("copy hi to the clipboard")).toList()
        val ask = events.single() as AssistantEvent.NeedsConfirmation
        assertEquals("clipboard_copy", ask.tool)
        assertEquals(0, clipboard.calls)
        val outcome = o.runConfirmed(ask.tool, ask.args) as AssistantEvent.ToolOutcome
        assertEquals(ToolResult.Success("Copied."), outcome.result)
        assertEquals(1, clipboard.calls)
    }

    @Test fun withoutAModelOpenConversationGetsAnHonestNotice() = runTest {
        val events = orchestrator(engine = null, error = "No model is selected.").handle("tell me a joke", user("tell me a joke")).toList()
        val notice = events.single() as AssistantEvent.Notice
        assertTrue(notice.text.startsWith("No model is selected."))
        assertTrue(notice.text.contains("device commands"))
    }

    @Test fun plainModelRepliesAreCleanedAndReturnedAsFinal() = runTest {
        val engine = FakeEngine(listOf("Hello", " there<end_of_turn>"))
        val events = orchestrator(engine).handle("hi", user("hi")).toList()
        assertEquals(AssistantEvent.Final("Hello there"), events.last())
        assertTrue(events.filterIsInstance<AssistantEvent.Partial>().isNotEmpty())
    }

    @Test fun emptyModelOutputIsReportedNotInvented() = runTest {
        val events = orchestrator(FakeEngine(listOf(""))).handle("hi", user("hi")).toList()
        assertTrue(events.single() is AssistantEvent.Notice)
    }

    @Test fun earlierConversationTurnsAreSentToTheModel() = runTest {
        val engine = FakeEngine(listOf("Your name is Ada."))
        val history = listOf(
            ChatTurn(Role.USER, "My name is Ada."),
            ChatTurn(Role.ASSISTANT, "Nice to meet you, Ada."),
            ChatTurn(Role.USER, "What is my name?"),
        )
        orchestrator(engine).handle("What is my name?", history).toList()
        val prompt = engine.lastPrompt
        assertNotNull(prompt)
        prompt!!
        assertTrue(prompt.contains("My name is Ada."))
        assertTrue(prompt.contains("Nice to meet you, Ada."))
        assertTrue(prompt.indexOf("My name is Ada.") < prompt.indexOf("What is my name?"))
        assertFalse(prompt.isBlank())
    }
}
