package com.jarvis.assistant

import com.jarvis.assistant.tools.Tool
import com.jarvis.assistant.tools.ToolExecutor
import com.jarvis.assistant.tools.ToolRegistry
import com.jarvis.assistant.tools.ToolResult
import com.jarvis.assistant.tools.ToolSpecs
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolExecutorTest {
    private class ExplodingTool : Tool {
        override val spec = ToolSpecs.battery
        override suspend fun execute(args: Map<String, String>): ToolResult = throw IllegalStateException("boom")
    }

    @Test fun unknownToolIsRejected() {
        val executor = ToolExecutor(ToolRegistry(emptyList()))
        assertTrue(executor.prepare("nope", emptyMap()) is ToolExecutor.Prepared.Rejected)
    }

    @Test fun invalidArgumentsAreRejectedBeforeExecution() {
        val tool = FakeTool(ToolSpecs.volume, ToolResult.Success("ok"))
        val executor = ToolExecutor(ToolRegistry(listOf(tool)))
        assertTrue(executor.prepare("set_volume", mapOf("percent" to "900")) is ToolExecutor.Prepared.Rejected)
        assertEquals(0, tool.calls)
    }

    @Test fun readyToolRuns() = runTest {
        val tool = FakeTool(ToolSpecs.volume, ToolResult.Success("done"))
        val executor = ToolExecutor(ToolRegistry(listOf(tool)))
        val prepared = executor.prepare("set_volume", mapOf("percent" to "40")) as ToolExecutor.Prepared.Ready
        assertEquals(ToolResult.Success("done"), executor.run(prepared.tool, prepared.args))
        assertEquals(mapOf("percent" to "40"), tool.lastArgs)
    }

    @Test fun toolExceptionsBecomeFailuresNotCrashes() = runTest {
        val executor = ToolExecutor(ToolRegistry(listOf(ExplodingTool())))
        val prepared = executor.prepare("device_battery", emptyMap()) as ToolExecutor.Prepared.Ready
        val result = executor.run(prepared.tool, prepared.args)
        assertTrue(result is ToolResult.Failure)
        assertTrue(result.message.contains("boom"))
    }
}
