package com.jarvis.assistant

import com.jarvis.assistant.ai.AssistantConfig
import com.jarvis.assistant.ai.LlmEngine
import com.jarvis.assistant.ai.ModelRunner
import com.jarvis.assistant.ai.ModelUnavailableException
import com.jarvis.assistant.ai.PromptTemplate
import com.jarvis.assistant.tools.Tool
import com.jarvis.assistant.tools.ToolResult
import com.jarvis.assistant.tools.ToolSpec
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.asFlow
import java.io.File

/**
 * Test doubles. They exist ONLY to test orchestration plumbing (routing, validation, confirmation, prompt
 * assembly). They are not a model and prove nothing about response quality; real inference is covered by
 * the on-device LocalModelEndToEndTest.
 */
class FakeConfig(
    override val assistantName: String = "Jarvis",
    override val promptTemplate: PromptTemplate = PromptTemplate.GEMMA,
    override val maxTokens: Int = 1024,
) : AssistantConfig

class FakeEngine(private val chunks: List<String>) : LlmEngine {
    override val backendName = "fake"
    override val supportedExtensions = setOf("task")
    override val isLoaded = true
    var lastPrompt: String? = null
    override suspend fun load(modelFile: File, maxTokens: Int) = Unit
    override fun generate(prompt: String): Flow<String> {
        lastPrompt = prompt
        return chunks.asFlow()
    }
    override fun unload() = Unit
}

class FakeRunner(private val engine: LlmEngine?, private val error: String = "No model is selected.") : ModelRunner {
    override suspend fun <T> use(block: suspend (LlmEngine) -> T): T {
        val e = engine ?: throw ModelUnavailableException(error)
        return block(e)
    }
}

class FakeTool(override val spec: ToolSpec, private val result: ToolResult) : Tool {
    var calls = 0
    var lastArgs: Map<String, String>? = null
    override suspend fun execute(args: Map<String, String>): ToolResult {
        calls++
        lastArgs = args
        return result
    }
}
