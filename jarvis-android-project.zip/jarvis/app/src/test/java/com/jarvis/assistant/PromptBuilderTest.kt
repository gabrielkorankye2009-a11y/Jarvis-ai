package com.jarvis.assistant

import com.jarvis.assistant.ai.ChatTurn
import com.jarvis.assistant.ai.PromptBuilder
import com.jarvis.assistant.ai.PromptTemplate
import com.jarvis.assistant.ai.Role
import com.jarvis.assistant.ai.SystemPrompt
import com.jarvis.assistant.tools.ToolSpecs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PromptBuilderTest {
    private val turns = listOf(
        ChatTurn(Role.USER, "My name is Ada."),
        ChatTurn(Role.ASSISTANT, "Nice to meet you, Ada."),
        ChatTurn(Role.USER, "What is my name?"),
    )

    @Test fun gemmaMergesSystemIntoFirstUserTurnAndEndsWithModelPrefix() {
        val p = PromptBuilder.render(PromptTemplate.GEMMA, "SYS", turns)
        assertTrue(p.startsWith("<start_of_turn>user\nSYS\n\nMy name is Ada.<end_of_turn>\n"))
        assertTrue(p.contains("<start_of_turn>model\nNice to meet you, Ada.<end_of_turn>\n"))
        assertTrue(p.endsWith("<start_of_turn>model\n"))
    }

    @Test fun chatmlAndLlama3AndPlainEndWithAssistantPrefix() {
        assertTrue(PromptBuilder.render(PromptTemplate.CHATML, "SYS", turns).startsWith("<|im_start|>system\nSYS<|im_end|>\n"))
        assertTrue(PromptBuilder.render(PromptTemplate.CHATML, "SYS", turns).endsWith("<|im_start|>assistant\n"))
        assertTrue(PromptBuilder.render(PromptTemplate.LLAMA3, "SYS", turns).endsWith("<|start_header_id|>assistant<|end_header_id|>\n\n"))
        assertTrue(PromptBuilder.render(PromptTemplate.PLAIN, "SYS", turns).endsWith("Assistant:"))
    }

    @Test fun earlierTurnsReachThePrompt() {
        val p = PromptBuilder.build(PromptTemplate.GEMMA, "SYS", turns, maxChars = 4000)
        assertTrue(p.contains("My name is Ada."))
        assertTrue(p.contains("What is my name?"))
    }

    @Test fun oldestTurnsAreDroppedFirstAndBudgetIsRespected() {
        val long = (1..10).map { i ->
            ChatTurn(if (i % 2 == 1) Role.USER else Role.ASSISTANT, "T$i" + "x".repeat(95))
        }
        val p = PromptBuilder.build(PromptTemplate.GEMMA, "SYS", long, maxChars = 600)
        assertTrue(p.length <= 600)
        assertFalse(p.contains("T1x"))
        assertTrue(p.contains("T9x"))
        assertTrue(p.contains("SYS")) // merged into the first kept user turn
    }

    @Test fun anOversizedSingleTurnIsTruncatedFromTheFront() {
        val p = PromptBuilder.build(
            PromptTemplate.CHATML, "SYS", listOf(ChatTurn(Role.USER, "a".repeat(5000) + "END")), maxChars = 300,
        )
        assertTrue(p.length <= 300)
        assertTrue(p.contains("END"))
        assertTrue(p.contains("SYS"))
    }

    @Test fun outputIsCutAtTheFirstEndOfTurnMarker() {
        assertEquals("Hello there", PromptBuilder.cleanOutput("Hello there<end_of_turn>\nignored"))
        assertEquals("Hi", PromptBuilder.cleanOutput("  Hi<|im_end|>"))
        assertEquals("plain", PromptBuilder.cleanOutput("plain"))
    }

    @Test fun systemPromptListsEveryToolAndTheCallFormat() {
        val prompt = SystemPrompt.build("Jarvis", ToolSpecs.all, "Monday 9 November 2026, 10:00")
        ToolSpecs.all.forEach { assertTrue("missing ${it.name}", prompt.contains(it.name)) }
        assertTrue(prompt.contains("<tool_call>"))
        assertTrue(prompt.contains("Jarvis"))
        assertTrue(prompt.contains("Monday 9 November 2026"))
        assertFalse(prompt.contains("TOOL_LIST"))
        assertTrue(prompt.contains("state: on|off"))
    }
}
