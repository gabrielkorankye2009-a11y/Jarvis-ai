package com.jarvis.assistant

import androidx.room.Room
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.jarvis.assistant.data.ChatRepository
import com.jarvis.assistant.data.JarvisDatabase
import com.jarvis.assistant.data.MessageKind
import com.jarvis.assistant.data.MessageRole
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/** Uses a real on-disk Room database and closes and reopens it, as happens when the app restarts. */
@RunWith(AndroidJUnit4::class)
class ChatPersistenceTest {
    private val context = InstrumentationRegistry.getInstrumentation().targetContext
    private val dbName = "persistence-test-${System.nanoTime()}.db"
    private var now = 1_000L

    private fun open() = Room.databaseBuilder(context, JarvisDatabase::class.java, dbName).build()

    @After
    fun cleanUp() {
        context.deleteDatabase(dbName)
    }

    @Test
    fun conversationsSurviveClosingAndReopeningTheDatabase() = runBlocking {
        val db1 = open()
        val repo1 = ChatRepository(db1.chatDao()) { now }
        val id = repo1.createConversation("Biology")
        now += 10
        repo1.addMessage(id, MessageRole.USER, MessageKind.TEXT, "My name is Ada.")
        now += 10
        repo1.addMessage(id, MessageRole.ASSISTANT, MessageKind.TEXT, "Nice to meet you, Ada.", toolName = null, outcome = null)
        db1.close()

        val db2 = open()
        val repo2 = ChatRepository(db2.chatDao()) { now }
        val messages = repo2.getMessages(id)
        assertEquals(listOf("My name is Ada.", "Nice to meet you, Ada."), messages.map { it.text })
        assertEquals(listOf(MessageRole.USER, MessageRole.ASSISTANT), messages.map { it.role })
        assertEquals("Biology", repo2.observeConversations().first().single().title)
        db2.close()
    }

    @Test
    fun deletingAConversationDeletesItsMessages() = runBlocking {
        val db = open()
        val repo = ChatRepository(db.chatDao()) { now }
        val id = repo.createConversation("To delete")
        repo.addMessage(id, MessageRole.USER, MessageKind.TEXT, "secret")
        repo.deleteConversation(id)
        assertTrue(repo.getMessages(id).isEmpty())
        assertTrue(repo.search("secret").isEmpty())
        db.close()
    }

    @Test
    fun searchTreatsLikeWildcardsLiterally() = runBlocking {
        val db = open()
        val repo = ChatRepository(db.chatDao()) { now }
        val id = repo.createConversation("Scores")
        repo.addMessage(id, MessageRole.USER, MessageKind.TEXT, "Score 100% today")
        repo.addMessage(id, MessageRole.USER, MessageKind.TEXT, "Score 1000 today")
        assertEquals(listOf("Score 100% today"), repo.search("100%").map { it.text })
        db.close()
    }

    @Test
    fun mostRecentlyActiveConversationListsFirst() = runBlocking {
        val db = open()
        val repo = ChatRepository(db.chatDao()) { now }
        val older = repo.createConversation("Older")
        now += 100
        val newer = repo.createConversation("Newer")
        now += 100
        repo.addMessage(older, MessageRole.USER, MessageKind.TEXT, "bump")
        assertEquals(listOf(older, newer), repo.observeConversations().first().map { it.id })
        db.close()
    }
}
