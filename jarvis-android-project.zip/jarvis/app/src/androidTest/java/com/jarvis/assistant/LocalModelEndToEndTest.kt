package com.jarvis.assistant

import android.app.Application
import android.os.Build
import android.util.Log
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.jarvis.assistant.ai.MediaPipeLlmEngine
import com.jarvis.assistant.ai.PromptTemplate
import com.jarvis.assistant.data.MessageKind
import com.jarvis.assistant.data.MessageRole
import com.jarvis.assistant.models.DeviceCapabilitiesReader
import com.jarvis.assistant.models.ModelRecommender
import com.jarvis.assistant.models.ModelStore
import com.jarvis.assistant.ui.chat.ChatUiState
import com.jarvis.assistant.ui.chat.ChatViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

/**
 * REAL END-TO-END TEST. Drives the same ChatViewModel, orchestrator, model manager, MediaPipe engine and Room
 * database the app uses, with a real language-model file, and simulates an app restart by shutting the first
 * container down and building a second one on the same database file.
 *
 * It is skipped (not passed) when no model is installed. Prerequisites and commands: docs/E2E_VERIFICATION.md.
 * Optional instrumentation arguments: jarvisModel (file name), jarvisTemplate (GEMMA, CHATML, LLAMA3, PLAIN).
 *
 * Replies come from a sampled model, so the memory question is attempted up to three times. The test never
 * contains any expected "Ada" answer: only the model reading the saved history can produce it.
 */
@RunWith(AndroidJUnit4::class)
class LocalModelEndToEndTest {
    private val app = InstrumentationRegistry.getInstrumentation().targetContext.applicationContext as Application
    private val args = InstrumentationRegistry.getArguments()
    private val report = StringBuilder()

    private fun note(line: String) {
        report.appendLine(line)
        Log.i(TAG, line)
    }

    private suspend fun sendAndAwait(vm: ChatViewModel, text: String, messagesBefore: Int): ChatUiState {
        val started = System.currentTimeMillis()
        vm.send(text)
        val state = withTimeout(TIMEOUT_MS) {
            vm.ui.first { !it.busy && it.messages.size >= messagesBefore + 2 && it.messages.last().role == MessageRole.ASSISTANT }
        }
        note("  took ${(System.currentTimeMillis() - started) / 1000.0} s")
        return state
    }

    @Test
    fun localModelAnswersSavesAndRemembersAcrossARestart() = runBlocking {
        val store = ModelStore(app)
        val caps = DeviceCapabilitiesReader.read(app, store.dir)
        val extensions = MediaPipeLlmEngine(app).supportedExtensions
        val ranked = ModelRecommender.rankInstalled(store.list(), caps, extensions)
        assumeTrue(
            "No .task/.bin model is installed in ${store.dir}. Import one in the app's Models tab, then re-run.",
            ranked.isNotEmpty(),
        )
        val modelName = args.getString("jarvisModel") ?: ranked.first().name
        assumeTrue("Model '$modelName' is not installed.", store.file(modelName) != null)

        val settings = AppSettings(app)
        val savedModel = settings.activeModel
        val savedTemplate = settings.promptTemplate
        val dbName = "e2e-${System.nanoTime()}.db"
        try {
            args.getString("jarvisTemplate")?.let { settings.promptTemplate = PromptTemplate.valueOf(it) }
            settings.activeModel = modelName

            note("JARVIS end-to-end report")
            note("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}, ABI ${Build.SUPPORTED_ABIS.firstOrNull()}")
            note("RAM: ${ModelRecommender.formatBytes(caps.totalRamBytes)} total, ${ModelRecommender.formatBytes(caps.availRamBytes)} free")
            note("Model: $modelName (${ModelRecommender.formatBytes(store.file(modelName)!!.length())}), template ${settings.promptTemplate}")

            // ---- Session 1: first message, answered by the local model and saved ----
            val container1 = AppContainer(app, dbName)
            val vm1 = ChatViewModel(container1)
            val first = "Hi! My name is Ada and my favourite subject is biology. Please greet me in one short sentence."
            note("Session 1, user: $first")
            val state1 = sendAndAwait(vm1, first, messagesBefore = 0)
            val reply1 = state1.messages.last()
            note("Session 1, assistant (${reply1.kind}): ${reply1.text}")
            assertEquals("The model did not answer: ${reply1.text}", MessageKind.TEXT, reply1.kind)
            assertTrue("Empty reply", reply1.text.isNotBlank())
            assertFalse("Reply is a raw tool call", reply1.text.contains("<tool_call>"))
            val conversationId = state1.conversationId!!

            // ---- Simulated restart: everything in memory is released, only the database file remains ----
            container1.shutdown()
            note("Simulated restart: container shut down, model unloaded, database closed.")

            val container2 = AppContainer(app, dbName)
            val vm2 = ChatViewModel(container2)
            vm2.select(conversationId)
            val restored = withTimeout(30_000) {
                vm2.ui.first { it.conversationId == conversationId && it.messages.size >= 2 }
            }
            assertEquals(
                "History after restart differs from what was saved",
                state1.messages.map { it.text }, restored.messages.map { it.text },
            )
            note("History restored from disk: ${restored.messages.size} messages, identical to before the restart.")

            // ---- Session 2: a question that is only answerable from the restored context ----
            var remembered = false
            var count = restored.messages.size
            for (attempt in 1..3) {
                val question = "What is my name? Answer in one short sentence."
                note("Session 2, attempt $attempt, user: $question")
                val state2 = sendAndAwait(vm2, question, messagesBefore = count)
                count = state2.messages.size
                val answer = state2.messages.last()
                note("Session 2, assistant (${answer.kind}): ${answer.text}")
                if (answer.kind == MessageKind.TEXT && answer.text.contains("Ada", ignoreCase = true)) {
                    remembered = true
                    break
                }
            }
            note(if (remembered) "RESULT: PASS. The model used context restored after the restart." else "RESULT: FAIL. The model did not recall the name in 3 attempts.")
            container2.shutdown()
            assertTrue("The model did not recall the name from restored history in 3 attempts. See report.", remembered)
        } finally {
            settings.activeModel = savedModel
            settings.promptTemplate = savedTemplate
            app.deleteDatabase(dbName)
            File(app.getExternalFilesDir(null) ?: app.filesDir, "e2e_report.txt").writeText(report.toString())
        }
    }

    private companion object {
        const val TAG = "JarvisE2E"
        const val TIMEOUT_MS = 10 * 60 * 1000L
    }
}
