package com.jarvis.assistant.ui.models

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.AppContainer
import com.jarvis.assistant.ai.PromptTemplate
import com.jarvis.assistant.models.DeviceCapabilities
import com.jarvis.assistant.models.DeviceCapabilitiesReader
import com.jarvis.assistant.models.ModelManagerState
import com.jarvis.assistant.models.ModelRecommender
import com.jarvis.assistant.models.Recommendation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DownloadUiState(val fraction: Float?, val text: String)

data class ModelsUiState(
    val caps: DeviceCapabilities? = null,
    val recommendation: Recommendation? = null,
    val manager: ModelManagerState = ModelManagerState(),
    val template: PromptTemplate = PromptTemplate.GEMMA,
    val maxTokens: Int = 1024,
    val wifiOnly: Boolean = true,
    val backendName: String = "",
    val supportedExtensions: Set<String> = emptySet(),
    val importProgress: Pair<Long, Long>? = null,
    val download: DownloadUiState? = null,
    val benchmarking: Boolean = false,
    val message: String? = null,
)

class ModelsViewModel(private val container: AppContainer) : ViewModel() {
    private val manager = container.modelManager
    private val settings = container.settings
    private val local = MutableStateFlow(ModelsUiState())
    private var downloadJob: Job? = null

    val ui: StateFlow<ModelsUiState> = combine(manager.state, local) { m, l -> l.copy(manager = m) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ModelsUiState())

    init {
        local.update {
            it.copy(
                template = settings.promptTemplate, maxTokens = settings.maxTokens, wifiOnly = settings.downloadWifiOnly,
                backendName = manager.backendName, supportedExtensions = manager.supportedExtensions,
            )
        }
        refreshDevice()
    }

    fun refreshDevice() {
        viewModelScope.launch(Dispatchers.Default) {
            val caps = DeviceCapabilitiesReader.read(container.app, container.modelStore.dir)
            local.update { it.copy(caps = caps, recommendation = ModelRecommender.recommend(caps)) }
            manager.refresh()
        }
    }

    fun import(uri: Uri) {
        viewModelScope.launch {
            local.update { it.copy(importProgress = 0L to -1L, message = null) }
            val result = container.modelStore.import(uri, manager.supportedExtensions) { done, total ->
                local.update { s -> s.copy(importProgress = done to total) }
            }
            val text = result.fold(
                onSuccess = { file -> "Imported ${file.name}." },
                onFailure = { e -> "Import failed: ${e.message}" },
            )
            local.update { it.copy(importProgress = null, message = text) }
            manager.refresh()
        }
    }

    fun startDownload(url: String) {
        val result = container.modelDownloader.start(url, settings.downloadWifiOnly)
        result.onFailure { e -> local.update { it.copy(message = "Download not started: ${e.message}") } }
        result.onSuccess { id -> track(id) }
    }

    private fun track(id: Long) {
        downloadJob?.cancel()
        downloadJob = viewModelScope.launch {
            while (true) {
                val p = container.modelDownloader.progress(id)
                if (p == null) {
                    local.update { it.copy(download = null, message = "The download is no longer in the system queue.") }
                    break
                }
                val fraction = if (p.total > 0) (p.bytes.toFloat() / p.total).coerceIn(0f, 1f) else null
                val text = ModelRecommender.formatBytes(p.bytes) +
                    if (p.total > 0) " of ${ModelRecommender.formatBytes(p.total)}" else ""
                local.update { it.copy(download = DownloadUiState(fraction, text)) }
                if (p.succeeded) {
                    local.update { it.copy(download = null, message = "Download finished.") }
                    manager.refresh()
                    break
                }
                if (p.failed) {
                    local.update { it.copy(download = null, message = "Download failed (system reason code ${p.reason}).") }
                    break
                }
                delay(1_000)
            }
        }
    }

    fun select(name: String) = manager.selectActive(name)

    fun load(name: String) {
        viewModelScope.launch {
            manager.load(name).onSuccess { local.update { it.copy(message = "Loaded $name.") } }
        }
    }

    fun unload() {
        viewModelScope.launch {
            val done = manager.unload()
            if (!done) local.update { it.copy(message = "The model is busy generating a reply.") }
        }
    }

    fun delete(name: String) {
        viewModelScope.launch {
            if (manager.state.value.loadedModel == name) manager.unload()
            if (settings.activeModel == name) manager.selectActive(null)
            val ok = container.modelStore.delete(name)
            manager.refresh()
            local.update { it.copy(message = if (ok) "Deleted $name." else "Could not delete $name.") }
        }
    }

    fun benchmark() {
        viewModelScope.launch {
            local.update { it.copy(benchmarking = true, message = null) }
            val result = manager.benchmark()
            local.update {
                it.copy(
                    benchmarking = false,
                    message = result.exceptionOrNull()?.let { e -> "Benchmark failed: ${e.message}" },
                )
            }
        }
    }

    fun setTemplate(t: PromptTemplate) {
        settings.promptTemplate = t
        local.update { it.copy(template = t) }
    }

    /** Applies to the next model load; a loaded model keeps its current context size. */
    fun setMaxTokens(n: Int) {
        settings.maxTokens = n
        local.update { it.copy(maxTokens = n) }
    }

    fun setWifiOnly(v: Boolean) {
        settings.downloadWifiOnly = v
        local.update { it.copy(wifiOnly = v) }
    }

    fun clearMessage() = local.update { it.copy(message = null) }
}
