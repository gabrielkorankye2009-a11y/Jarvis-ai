package com.jarvis.assistant.tools

import java.util.Locale

enum class ParamType { STRING, INT, ENUM }

data class ToolParam(
    val name: String,
    val type: ParamType,
    val description: String,
    val required: Boolean = true,
    val min: Int? = null,
    val max: Int? = null,
    val allowed: List<String> = emptyList(),
)

/** Pure description of a tool. No Android types, so it can be unit-tested on the JVM. */
data class ToolSpec(
    val name: String,
    val description: String,
    val params: List<ToolParam> = emptyList(),
    /** Names of capability-registry entries this tool implements. Checked against the registry in tests. */
    val registryNames: List<String>,
    val requiresConfirmation: Boolean = false,
)

/**
 * Outcome of a tool run. Messages shown to the user come from here, never from model text,
 * so the assistant cannot claim success that did not happen.
 */
sealed interface ToolResult {
    val message: String

    /** The operation was performed and, where the platform allows, verified. */
    data class Success(override val message: String) : ToolResult

    /** A system screen or another app was opened. Completion cannot be verified by this app. */
    data class HandedOff(override val message: String) : ToolResult

    data class Failure(override val message: String) : ToolResult
}

object Format {
    fun duration(totalSeconds: Int): String {
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        val parts = buildList {
            if (h > 0) add(plural(h, "hour"))
            if (m > 0) add(plural(m, "minute"))
            if (s > 0) add(plural(s, "second"))
        }
        return if (parts.isEmpty()) "0 seconds" else parts.joinToString(" ")
    }

    private fun plural(n: Int, unit: String) = if (n == 1) "$n $unit" else "$n ${unit}s"

    fun clock(hour: Int, minute: Int): String = String.format(Locale.ROOT, "%02d:%02d", hour, minute)
}

object ToolValidator {
    const val MAX_STRING = 500

    sealed interface Validation {
        data class Valid(val args: Map<String, String>) : Validation
        data class Invalid(val reason: String) : Validation
    }

    /** Checks required arguments, types, ranges and enums. Unknown arguments are dropped. */
    fun validate(spec: ToolSpec, raw: Map<String, String>): Validation {
        val out = LinkedHashMap<String, String>()
        for (p in spec.params) {
            val value = raw[p.name]?.trim()
            if (value.isNullOrEmpty()) {
                if (p.required) return Validation.Invalid("Missing required argument '${p.name}' for ${spec.name}.")
                continue
            }
            when (p.type) {
                ParamType.STRING -> {
                    if (value.length > MAX_STRING) {
                        return Validation.Invalid("'${p.name}' is longer than $MAX_STRING characters.")
                    }
                    out[p.name] = value
                }
                ParamType.INT -> {
                    val n = value.toIntOrNull()
                        ?: value.toDoubleOrNull()?.takeIf { it % 1.0 == 0.0 }?.toInt()
                        ?: return Validation.Invalid("'${p.name}' must be a whole number.")
                    val lo = p.min
                    val hi = p.max
                    if (lo != null && n < lo) return Validation.Invalid("'${p.name}' must be at least $lo.")
                    if (hi != null && n > hi) return Validation.Invalid("'${p.name}' must be at most $hi.")
                    out[p.name] = n.toString()
                }
                ParamType.ENUM -> {
                    val v = value.lowercase()
                    if (v !in p.allowed) {
                        return Validation.Invalid("'${p.name}' must be one of: ${p.allowed.joinToString(", ")}.")
                    }
                    out[p.name] = v
                }
            }
        }
        return Validation.Valid(out)
    }
}

object ToolSpecs {
    val battery = ToolSpec(
        name = "device_battery",
        description = "Read the battery level and charging state.",
        registryNames = listOf("Battery information"),
    )
    val storage = ToolSpec(
        name = "device_storage",
        description = "Read free and total internal storage.",
        registryNames = listOf("Storage information"),
    )
    val deviceInfo = ToolSpec(
        name = "device_info",
        description = "Read the device model, Android version, CPU architecture and RAM.",
        registryNames = listOf("Device information"),
    )
    val network = ToolSpec(
        name = "network_status",
        description = "Read airplane-mode state and whether the phone has a working internet connection.",
        registryNames = listOf("Airplane-mode status", "Available network information"),
    )
    val flashlight = ToolSpec(
        name = "flashlight",
        description = "Turn the flashlight on or off.",
        params = listOf(ToolParam("state", ParamType.ENUM, "on or off", allowed = listOf("on", "off"))),
        registryNames = listOf("Flashlight control"),
    )
    val volume = ToolSpec(
        name = "set_volume",
        description = "Set the media volume as a percentage.",
        params = listOf(ToolParam("percent", ParamType.INT, "volume percentage", min = 0, max = 100)),
        registryNames = listOf("Volume adjustment"),
    )
    val openSettings = ToolSpec(
        name = "open_settings",
        description = "Open a system settings screen. It cannot change the setting itself.",
        params = listOf(
            ToolParam(
                "screen", ParamType.ENUM, "which settings screen",
                allowed = listOf("wifi", "bluetooth", "display", "sound", "battery_saver", "location", "notifications"),
            ),
        ),
        registryNames = listOf(
            "Wi-Fi settings access", "Bluetooth settings access", "Display settings", "Sound settings",
            "Power-saving settings", "Notification settings", "Location settings handoff",
        ),
    )
    val timer = ToolSpec(
        name = "set_timer",
        description = "Ask the system clock app to start a countdown timer.",
        params = listOf(ToolParam("seconds", ParamType.INT, "duration in seconds", min = 1, max = 86_400)),
        registryNames = listOf("Countdown timers"),
    )
    val alarm = ToolSpec(
        name = "set_alarm",
        description = "Ask the system clock app to create an alarm. Uses the 24-hour clock.",
        params = listOf(
            ToolParam("hour", ParamType.INT, "hour, 24-hour clock", min = 0, max = 23),
            ToolParam("minute", ParamType.INT, "minute", min = 0, max = 59),
            ToolParam("label", ParamType.STRING, "optional label", required = false),
        ),
        registryNames = listOf("Create alarm"),
    )
    val openApp = ToolSpec(
        name = "open_app",
        description = "Open an installed app by the name shown on the launcher.",
        params = listOf(ToolParam("app_name", ParamType.STRING, "app name")),
        registryNames = listOf("Opening applications"),
    )
    val clipboard = ToolSpec(
        name = "clipboard_copy",
        description = "Copy text to the clipboard. The user must confirm first.",
        params = listOf(ToolParam("text", ParamType.STRING, "text to copy")),
        registryNames = listOf("Clipboard operations with appropriate user consent", "Sensitive action confirmations"),
        requiresConfirmation = true,
    )

    val all: List<ToolSpec> = listOf(
        battery, storage, deviceInfo, network, flashlight, volume, openSettings, timer, alarm, openApp, clipboard,
    )
}
