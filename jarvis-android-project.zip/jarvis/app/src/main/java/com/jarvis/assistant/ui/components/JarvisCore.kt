package com.jarvis.assistant.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.ui.theme.JarvisColors

/** Animated circular indicator. Spins faster while [active] (the assistant is working). */
@Composable
fun JarvisCore(active: Boolean, modifier: Modifier = Modifier.size(44.dp)) {
    val transition = rememberInfiniteTransition(label = "core")
    val sweep by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (active) 1800 else 7000, easing = LinearEasing)),
        label = "sweep",
    )
    val pulse by transition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )
    Canvas(modifier) {
        val stroke = Stroke(width = size.minDimension * 0.07f, cap = StrokeCap.Round)
        val inset = stroke.width
        val outer = Size(size.width - 2 * inset, size.height - 2 * inset)
        drawArc(
            color = JarvisColors.Cyan, startAngle = sweep, sweepAngle = 110f, useCenter = false,
            topLeft = Offset(inset, inset), size = outer, style = stroke,
        )
        drawArc(
            color = JarvisColors.Blue, startAngle = -sweep * 1.4f, sweepAngle = 70f, useCenter = false,
            topLeft = Offset(inset * 3, inset * 3), size = Size(outer.width - 4 * inset, outer.height - 4 * inset),
            style = stroke,
        )
        drawCircle(
            color = JarvisColors.Cyan.copy(alpha = if (active) 0.55f else 0.25f),
            radius = size.minDimension * 0.16f * pulse,
        )
    }
}
