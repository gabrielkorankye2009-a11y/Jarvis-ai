package com.jarvis.assistant.ui.models

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.ai.PromptTemplate
import com.jarvis.assistant.models.ModelRecommender
import com.jarvis.assistant.ui.theme.JarvisColors

@Composable
fun ModelsScreen(vm: ModelsViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.import(uri)
    }
    var url by rememberSaveable { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<String?>(null) }
    val manager = ui.manager

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("AI models", style = MaterialTheme.typography.headlineSmall, color = JarvisColors.Cyan)

        ui.message?.let { msg ->
            Section("Status") {
                Text(msg)
                TextButton(onClick = { vm.clearMessage() }) { Text("Dismiss") }
            }
        }
        manager.lastError?.let { Section("Problem") { Text(it, color = JarvisColors.Error) } }
        manager.notice?.let { Section("Heads up") { Text(it, color = JarvisColors.Warn) } }
        if (manager.loading) {
            Section("Loading model") {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text("This can take a while for large models.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Section("This device") {
            val caps = ui.caps
            val rec = ui.recommendation
            if (caps == null || rec == null) {
                Text("Reading device details…")
            } else {
                Text("RAM: ${ModelRecommender.formatBytes(caps.totalRamBytes)} total, ${ModelRecommender.formatBytes(caps.availRamBytes)} free now")
                Text("Free storage: ${ModelRecommender.formatBytes(caps.freeStorageBytes)}")
                Text("CPU: ${caps.abis.firstOrNull() ?: "unknown"}, ${caps.cpuCores} cores")
                Text("Suggested profile: ${rec.tier.label}", fontWeight = FontWeight.SemiBold, color = JarvisColors.Cyan)
                Text(rec.tier.blurb, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Suggested model file size up to about ${ModelRecommender.formatBytes(rec.maxModelBytes)}.")
                rec.notes.forEach { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }

        Section("Installed models") {
            Text("Backend: ${ui.backendName} (loads ${ui.supportedExtensions.joinToString { ".$it" }} files)", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (manager.models.isEmpty()) {
                Text("No models yet. Import a file or download one below.")
            }
            manager.models.forEach { model ->
                val loaded = manager.loadedModel == model.name
                val active = manager.activeModel == model.name
                val supported = model.name.substringAfterLast('.', "").lowercase() in ui.supportedExtensions
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = JarvisColors.SurfaceHigh,
                    border = BorderStroke(1.dp, if (active) JarvisColors.Cyan else MaterialTheme.colorScheme.outline),
                ) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(model.name, fontWeight = FontWeight.SemiBold)
                        Text(
                            ModelRecommender.formatBytes(model.bytes) +
                                (if (loaded) " · loaded" else "") + (if (active) " · selected" else ""),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (!supported) Text("This backend cannot load this file type.", color = JarvisColors.Warn)
                        Row {
                            if (!active) TextButton(onClick = { vm.select(model.name) }) { Text("Select") }
                            if (loaded) {
                                TextButton(onClick = { vm.unload() }) { Text("Unload") }
                            } else {
                                TextButton(onClick = { vm.load(model.name) }, enabled = supported && !manager.loading) { Text("Load") }
                            }
                            TextButton(onClick = { deleteTarget = model.name }) { Text("Delete") }
                        }
                    }
                }
            }
        }

        Section("Import a model file") {
            Text(
                "Pick a model file already on this phone. It is copied into app-private storage; nothing is uploaded.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = ui.importProgress == null) { Text("Choose file") }
            ui.importProgress?.let { (done, total) ->
                if (total > 0) {
                    LinearProgressIndicator(progress = { (done.toFloat() / total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
                Text("Copied ${ModelRecommender.formatBytes(done)}")
            }
        }

        Section("Download from a link") {
            Text(
                "Uses the internet only when you tap Download. Many model hosts require you to accept a licence and sign in; for those, download in a browser and import the file instead.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                value = url, onValueChange = { url = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("https:// link to a model file") }, singleLine = true,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = ui.wifiOnly, onCheckedChange = { vm.setWifiOnly(it) })
                Spacer(Modifier.width(8.dp))
                Text("Wi-Fi only")
            }
            Button(onClick = { vm.startDownload(url) }, enabled = url.isNotBlank() && ui.download == null) { Text("Download") }
            ui.download?.let { d ->
                val f = d.fraction
                if (f != null) LinearProgressIndicator(progress = { f }, modifier = Modifier.fillMaxWidth())
                else LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(d.text)
            }
        }

        Section("Prompt format and context") {
            Text("Must match the model family, or replies will be poor.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PromptTemplate.entries.forEach { t ->
                    FilterChip(selected = ui.template == t, onClick = { vm.setTemplate(t) }, label = { Text(t.label) })
                }
            }
            Text("Context length (tokens)")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(512, 1024, 2048, 4096).forEach { n ->
                    FilterChip(selected = ui.maxTokens == n, onClick = { vm.setMaxTokens(n) }, label = { Text(n.toString()) })
                }
            }
            Text("Applies the next time a model is loaded. Larger values use more memory.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Section("Benchmark") {
            Text("Measures this phone with the loaded model. Nothing is estimated.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = { vm.benchmark() }, enabled = manager.loadedModel != null && !ui.benchmarking) {
                Text(if (ui.benchmarking) "Running…" else "Run benchmark")
            }
            manager.benchmark?.let { b ->
                Text("First text after ${b.firstChunkMs} ms")
                Text("About ${"%.1f".format(b.charsPerSecond)} characters per second (${b.chars} characters in ${b.totalMs} ms)")
            }
        }
    }

    deleteTarget?.let { name ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete model?") },
            text = { Text("$name will be removed from this phone. You can import it again later.") },
            confirmButton = { TextButton(onClick = { vm.delete(name); deleteTarget = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Keep") } },
        )
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = JarvisColors.Surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = JarvisColors.Cyan)
            content()
        }
    }
}
