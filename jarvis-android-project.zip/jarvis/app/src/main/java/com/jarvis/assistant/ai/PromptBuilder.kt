package com.jarvis.assistant.ai

import com.jarvis.assistant.tools.ParamType
import com.jarvis.assistant.tools.ToolParam
import com.jarvis.assistant.tools.ToolSpec

enum class PromptTemplate(val label: String) {
    GEMMA("Gemma"),
    CHATML("ChatML (Qwen and others)"),
    LLAMA3("Llama 3"),
    PLAIN("Plain text"),
}

enum class Role { USER, ASSISTANT }

data class ChatTurn(val role: Role, val text: String)

object PromptBuilder {
    private val stopTokens = listOf(
        "<end_of_turn>", "<start_of_turn>", "<|im_end|>", "<|im_start|>", "<|eot_id|>", "<eos>", "</s>",
    )

    /** Renders the conversation, dropping the oldest turns until it fits [maxChars]. The system prompt is always kept. */
    fun build(template: PromptTemplate, system: String, history: List<ChatTurn>, maxChars: Int): String {
        var turns = history
        while (turns.size > 1 && render(template, system, turns).length > maxChars) {
            turns = turns.drop(1)
            while (turns.size > 1 && turns.first().role == Role.ASSISTANT) turns = turns.drop(1)
        }
        var out = render(template, system, turns)
        if (out.length > maxChars && turns.isNotEmpty()) {
            val last = turns.last()
            val overhead = render(template, system, listOf(last.copy(text = ""))).length
            val room = (maxChars - overhead).coerceAtLeast(0)
            turns = listOf(last.copy(text = last.text.takeLast(room)))
            out = render(template, system, turns)
        }
        return out
    }

    fun render(template: PromptTemplate, system: String, turns: List<ChatTurn>): String {
        val sb = StringBuilder()
        when (template) {
            PromptTemplate.GEMMA -> {
                turns.forEachIndexed { i, t ->
                    if (t.role == Role.USER) {
                        sb.append("<start_of_turn>user\n")
                        if (i == 0 && system.isNotBlank()) sb.append(system).append("\n\n")
                        sb.append(t.text).append("<end_of_turn>\n")
                    } else {
                        sb.append("<start_of_turn>model\n").append(t.text).append("<end_of_turn>\n")
                    }
                }
                sb.append("<start_of_turn>model\n")
            }
            PromptTemplate.CHATML -> {
                sb.append("<|im_start|>system\n").append(system).append("<|im_end|>\n")
                turns.forEach { t ->
                    val r = if (t.role == Role.USER) "user" else "assistant"
                    sb.append("<|im_start|>").append(r).append("\n").append(t.text).append("<|im_end|>\n")
                }
                sb.append("<|im_start|>assistant\n")
            }
            PromptTemplate.LLAMA3 -> {
                sb.append("<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n")
                    .append(system).append("<|eot_id|>")
                turns.forEach { t ->
                    val r = if (t.role == Role.USER) "user" else "assistant"
                    sb.append("<|start_header_id|>").append(r).append("<|end_header_id|>\n\n")
                        .append(t.text).append("<|eot_id|>")
                }
                sb.append("<|start_header_id|>assistant<|end_header_id|>\n\n")
            }
            PromptTemplate.PLAIN -> {
                sb.append("System: ").append(system).append("\n\n")
                turns.forEach { t ->
                    sb.append(if (t.role == Role.USER) "User: " else "Assistant: ").append(t.text).append("\n")
                }
                sb.append("Assistant:")
            }
        }
        return sb.toString()
    }

    /** Cuts the model output at the first end-of-turn marker and trims it. */
    fun cleanOutput(raw: String): String {
        var end = raw.length
        for (token in stopTokens) {
            val i = raw.indexOf(token)
            if (i in 0 until end) end = i
        }
        return raw.substring(0, end).trim()
    }
}

object SystemPrompt {
    fun build(assistantName: String, tools: List<ToolSpec>, nowText: String): String {
        val toolLines = tools.joinToString("\n") { "- ${it.name}(${signature(it)}): ${it.description}" }
        // The tool list is substituted after trimIndent so its unindented lines do not defeat the indentation trim.
        return """
            You are $assistantName, a calm, precise and helpful personal assistant running entirely on the user's Android phone. The local time is $nowText.
            Rules:
            - Be concise. If you do not know something, say so. Never invent facts about the phone or the user.
            - To use a device tool, reply with ONLY a tool call and no other text, exactly in this form:
            <tool_call>{"name": "TOOL_NAME", "arguments": {"ARGUMENT": "VALUE"}}</tool_call>
            - You do not see a tool's result. The app runs the tool and shows the real result. Never claim that an action was done, sent, saved or changed.
            - If a request is ambiguous, for example a time without AM or PM, ask one short question instead of calling a tool.
            Available tools:
            TOOL_LIST
        """.trimIndent().replace("TOOL_LIST", toolLines)
    }

    private fun signature(spec: ToolSpec): String = spec.params.joinToString(", ") { p ->
        val type = when (p.type) {
            ParamType.STRING -> "text"
            ParamType.INT -> "number" + range(p)
            ParamType.ENUM -> p.allowed.joinToString("|")
        }
        p.name + (if (p.required) "" else "?") + ": " + type
    }

    private fun range(p: ToolParam): String {
        val lo = p.min
        val hi = p.max
        return if (lo != null && hi != null) " $lo-$hi" else ""
    }
}
