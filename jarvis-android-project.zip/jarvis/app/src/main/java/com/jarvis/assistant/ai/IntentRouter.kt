package com.jarvis.assistant.ai

import kotlin.math.roundToInt

sealed interface RouteOutcome {
    data class Command(val tool: String, val args: Map<String, String>) : RouteOutcome
    data class Clarify(val question: String) : RouteOutcome
    data object NoMatch : RouteOutcome
}

/**
 * Deterministic command router. Runs before the language model so common device commands work
 * instantly, without a model, and cannot be mangled by a small model. Anything it does not
 * recognise falls through to the model.
 */
object IntentRouter {
    private val ci = RegexOption.IGNORE_CASE

    private val prefix = Regex("""^(?:(?:please|hey|ok|okay|jarvis|j\.a\.r\.v\.i\.s\.?)[,:]?\s+)+""", ci)
    private val suffix = Regex("""(?:,?\s*please)?[.!?\s]*$""", ci)
    private val clip = Regex("""^copy\s+(.+?)\s+to\s+(?:the\s+|my\s+)?clipboard$""", ci)
    private val settings = Regex("""\b(wi-?fi|bluetooth|display|sound|battery saver|power saving|location|notification)s?\s+settings?\b""", ci)
    private val settingsVerb = Regex("""^(?:open|show|go to|take me to|launch|bring up)\b""", ci)
    private val question = Regex("""^(?:what|how|why|explain|tell|when|who)\b""", ci)
    private val timerWord = Regex("""\btimer\b""", ci)
    private val duration = Regex("""(\d+(?:\.\d+)?)\s*-?\s*(hours?|hrs?|minutes?|mins?|seconds?|secs?)\b""", ci)
    private val spokenDuration = Regex("""\b(half an hour|an hour|a minute|a second)\b""", ci)
    private val alarmWord = Regex("""\balarm\b|\bwake me\b""", ci)
    private val alarmTime = Regex("""(?:\b(?:at|for)\s+|\balarm\s+)(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)?(?![\w:])""", ci)
    private val flash = Regex("""^(?:turn|switch|put|set|enable|disable|toggle)\b.*\b(?:flash ?light|torch)\b|^(?:the\s+)?(?:flash ?light|torch)\s+(?:on|off)\b""", ci)
    private val offWord = Regex("""\boff\b|\bdisable\b""", ci)
    private val onWord = Regex("""\bon\b|\benable\b""", ci)
    private val volumeWord = Regex("""\bvolume\b""", ci)
    private val volumeVerb = Regex("""^(?:set|turn|change|make|adjust|put|lower|raise|increase|decrease|volume)\b""", ci)
    private val volumeNumber = Regex("""\b(?:to|at)\s+(\d{1,3})\s*(?:%|percent)?(?![\w])|\b(\d{1,3})\s*(?:%|percent)""", ci)
    private val batteryWord = Regex("""\bbattery\b""", ci)
    private val batteryExclude = Regex("""\b(saver|settings?)\b""", ci)
    private val storageWord = Regex("""\b(storage|free space|disk space)\b""", ci)
    private val deviceInfoWord = Regex("""\b(device info(?:rmation)?|phone info(?:rmation)?|about (?:my|this) (?:phone|device)|which phone|what phone)\b""", ci)
    private val networkWord = Regex("""\b(airplane mode|flight mode|am i (?:online|connected)|internet connection|network status|connectivity|is (?:the )?internet)\b""", ci)
    private val openApp = Regex("""^(?:open|launch|start|run)\s+(?:the\s+)?(.+?)(?:\s+app(?:lication)?)?$""", ci)
    private val article = Regex("""^(?:a|an)\s""", ci)
    private val openAppExclude = Regex("""\b(timer|alarm|settings?)\b""", ci)
    private val myPrefix = Regex("""^my\s+""", ci)
    private val spaces = Regex("""\s+""")

    private val settingsScreens = mapOf(
        "wifi" to "wifi", "wi-fi" to "wifi", "bluetooth" to "bluetooth", "display" to "display",
        "sound" to "sound", "battery saver" to "battery_saver", "power saving" to "battery_saver",
        "location" to "location", "notification" to "notifications",
    )

    fun clean(input: String): String = suffix.replace(prefix.replace(input.trim(), ""), "").trim()

    private fun words(s: String) = s.split(spaces).count { it.isNotEmpty() }

    fun route(input: String): RouteOutcome {
        val t = clean(input)
        if (t.isEmpty()) return RouteOutcome.NoMatch

        clip.matchEntire(t)?.let {
            return RouteOutcome.Command("clipboard_copy", mapOf("text" to it.groupValues[1]))
        }

        settings.find(t)?.let { m ->
            if (settingsVerb.containsMatchIn(t) || words(t) <= 4) {
                val screen = settingsScreens[m.groupValues[1].lowercase()]
                if (screen != null) return RouteOutcome.Command("open_settings", mapOf("screen" to screen))
            }
        }

        if (timerWord.containsMatchIn(t) && !question.containsMatchIn(t)) {
            var seconds = 0.0
            var found = false
            for (m in duration.findAll(t)) {
                found = true
                val unit = m.groupValues[2].lowercase()
                val mult = when {
                    unit.startsWith("h") -> 3600.0
                    unit.startsWith("m") -> 60.0
                    else -> 1.0
                }
                seconds += m.groupValues[1].toDouble() * mult
            }
            for (m in spokenDuration.findAll(t)) {
                found = true
                seconds += when (m.groupValues[1].lowercase()) {
                    "half an hour" -> 1800.0
                    "an hour" -> 3600.0
                    "a minute" -> 60.0
                    else -> 1.0
                }
            }
            if (!found) return RouteOutcome.Clarify("How long should the timer run?")
            return RouteOutcome.Command("set_timer", mapOf("seconds" to seconds.roundToInt().toString()))
        }

        if (alarmWord.containsMatchIn(t) && !question.containsMatchIn(t)) {
            val m = alarmTime.find(t) ?: return RouteOutcome.Clarify("What time should the alarm ring?")
            var hour = m.groupValues[1].toInt()
            val minute = if (m.groupValues[2].isEmpty()) 0 else m.groupValues[2].toInt()
            val meridiem = m.groupValues[3].replace(".", "").lowercase()
            if (hour > 23 || minute > 59) {
                return RouteOutcome.Clarify("I didn't understand that time. Try something like 7:30 AM.")
            }
            if (meridiem.isNotEmpty()) {
                if (hour > 12 || hour == 0) {
                    return RouteOutcome.Clarify("That time mixes 24-hour and AM/PM. Which do you mean?")
                }
                hour = (if (hour == 12) 0 else hour) + (if (meridiem == "pm") 12 else 0)
            } else if (hour in 1..12) {
                return RouteOutcome.Clarify(
                    "Do you mean $hour:${minute.toString().padStart(2, '0')} AM or PM?",
                )
            }
            return RouteOutcome.Command("set_alarm", mapOf("hour" to hour.toString(), "minute" to minute.toString()))
        }

        if (flash.containsMatchIn(t)) {
            return when {
                offWord.containsMatchIn(t) -> RouteOutcome.Command("flashlight", mapOf("state" to "off"))
                onWord.containsMatchIn(t) -> RouteOutcome.Command("flashlight", mapOf("state" to "on"))
                else -> RouteOutcome.Clarify("Do you want the flashlight on or off?")
            }
        }

        if (volumeWord.containsMatchIn(t) && volumeVerb.containsMatchIn(t)) {
            val m = volumeNumber.find(t)
                ?: return RouteOutcome.Clarify("What volume level, from 0 to 100 percent?")
            val value = m.groupValues[1].ifEmpty { m.groupValues[2] }
            return RouteOutcome.Command("set_volume", mapOf("percent" to value))
        }

        val w = words(t)
        if (batteryWord.containsMatchIn(t) && w <= 8 && !batteryExclude.containsMatchIn(t)) {
            return RouteOutcome.Command("device_battery", emptyMap())
        }
        if (storageWord.containsMatchIn(t) && w <= 8) return RouteOutcome.Command("device_storage", emptyMap())
        if (deviceInfoWord.containsMatchIn(t) && w <= 8) return RouteOutcome.Command("device_info", emptyMap())
        if (networkWord.containsMatchIn(t) && w <= 10) return RouteOutcome.Command("network_status", emptyMap())

        openApp.matchEntire(t)?.let { m ->
            val name = myPrefix.replace(m.groupValues[1].trim(), "")
            if (words(name) <= 4 && !article.containsMatchIn(name) && !openAppExclude.containsMatchIn(name)) {
                return RouteOutcome.Command("open_app", mapOf("app_name" to name))
            }
        }
        return RouteOutcome.NoMatch
    }
}
