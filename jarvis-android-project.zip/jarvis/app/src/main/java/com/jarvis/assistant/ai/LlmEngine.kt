package com.jarvis.assistant.ai

import kotlinx.coroutines.flow.Flow
import java.io.File

/**
 * The only thing the rest of the app knows about a model runtime. A second backend (LiteRT-LM, llama.cpp)
 * can be added by implementing this interface without touching the orchestrator, UI or tests.
 */
interface LlmEngine {
    val backendName: String

    /** Lower-case file extensions this backend can load, without the dot. */
    val supportedExtensions: Set<String>

    val isLoaded: Boolean

    /** Loads [modelFile]. Throws on failure; callers turn the exception into a user-readable message. */
    suspend fun load(modelFile: File, maxTokens: Int)

    /** Streams the reply as incremental text chunks. The flow fails if no model is loaded. */
    fun generate(prompt: String): Flow<String>

    fun unload()
}

/** Thrown when no model can be provided (none selected, file missing, too large, load failed). The message is user-readable. */
class ModelUnavailableException(message: String) : Exception(message)

/** What the orchestrator needs from model management. Implemented by ModelManager; faked in unit tests. */
interface ModelRunner {
    /** Runs [block] with a loaded engine, loading it first if needed. Throws [ModelUnavailableException] on failure. */
    suspend fun <T> use(block: suspend (LlmEngine) -> T): T
}

/** The settings the orchestrator reads. Implemented by AppSettings; faked in unit tests. */
interface AssistantConfig {
    val assistantName: String
    val promptTemplate: PromptTemplate
    val maxTokens: Int
}
