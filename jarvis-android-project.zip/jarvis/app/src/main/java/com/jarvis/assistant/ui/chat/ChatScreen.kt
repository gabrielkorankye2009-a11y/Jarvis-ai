package com.jarvis.assistant.ui.chat

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.data.ConversationEntity
import com.jarvis.assistant.data.MessageEntity
import com.jarvis.assistant.data.MessageKind
import com.jarvis.assistant.data.MessageRole
import com.jarvis.assistant.data.Outcome
import com.jarvis.assistant.ui.components.JarvisCore
import com.jarvis.assistant.ui.theme.JarvisColors

@Composable
fun ChatScreen(vm: ChatViewModel, onOpenModels: () -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var input by rememberSaveable { mutableStateOf("") }
    var showHistory by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<ConversationEntity?>(null) }
    val listState = rememberLazyListState()
    val itemCount = ui.messages.size + if (ui.streaming != null) 1 else 0

    LaunchedEffect(itemCount, ui.streaming) {
        if (itemCount > 0) listState.scrollToItem(itemCount - 1)
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            JarvisCore(active = ui.busy)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("J.A.R.V.I.S.", fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp, color = JarvisColors.Cyan)
                Text(
                    if (ui.busy) "Working…" else "Ready",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            TextButton(onClick = { showHistory = !showHistory }) { Text(if (showHistory) "Chat" else "History") }
            TextButton(onClick = { vm.newConversation(); showHistory = false }) { Text("New") }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)

        if (showHistory) {
            HistoryList(
                conversations = ui.conversations,
                selected = ui.conversationId,
                onSelect = { vm.select(it); showHistory = false },
                onDelete = { deleteTarget = it },
                modifier = Modifier.weight(1f).fillMaxWidth(),
            )
        } else {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (itemCount == 0) {
                    EmptyHint(onOpenModels, Modifier.align(Alignment.Center))
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(ui.messages, key = { it.id }) { MessageBubble(it) }
                        ui.streaming?.let { text ->
                            item { Bubble(text = text, label = null, labelColor = Color.Unspecified, isUser = false) }
                        }
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message or command") },
                maxLines = 4,
            )
            Spacer(Modifier.width(8.dp))
            if (ui.busy) {
                OutlinedButton(onClick = { vm.stop() }) { Text("Stop") }
            } else {
                Button(onClick = { vm.send(input); input = "" }, enabled = input.isNotBlank()) { Text("Send") }
            }
        }
    }

    ui.pending?.let { action ->
        AlertDialog(
            onDismissRequest = { vm.cancelPending() },
            title = { Text("Confirm action") },
            text = { Text(action.prompt) },
            confirmButton = { TextButton(onClick = { vm.confirmPending() }) { Text("Confirm") } },
            dismissButton = { TextButton(onClick = { vm.cancelPending() }) { Text("Cancel") } },
        )
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete conversation?") },
            text = { Text("\"${target.title}\" and all its messages will be permanently deleted from this phone.") },
            confirmButton = {
                TextButton(onClick = { vm.delete(target.id); deleteTarget = null }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Keep") } },
        )
    }
}

@Composable
private fun EmptyHint(onOpenModels: () -> Unit, modifier: Modifier) {
    Column(modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Try a command", fontWeight = FontWeight.SemiBold)
        Text(
            "\"battery\", \"flashlight on\", \"set a 10 minute timer\", \"open Maps\".\nThese run without a model.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.padding(6.dp))
        Text(
            "For open conversation, load a local model.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        TextButton(onClick = onOpenModels) { Text("Open Models") }
    }
}

@Composable
private fun HistoryList(
    conversations: List<ConversationEntity>,
    selected: Long?,
    onSelect: (Long) -> Unit,
    onDelete: (ConversationEntity) -> Unit,
    modifier: Modifier,
) {
    if (conversations.isEmpty()) {
        Box(modifier, contentAlignment = Alignment.Center) {
            Text("No saved conversations yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }
    LazyColumn(modifier, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(conversations, key = { it.id }) { c ->
            Surface(
                color = if (c.id == selected) JarvisColors.SurfaceHigh else JarvisColors.Surface,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
                Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(c.title, modifier = Modifier.weight(1f).clickable { onSelect(c.id) }.padding(vertical = 14.dp), maxLines = 1)
                    TextButton(onClick = { onDelete(c) }) { Text("Delete") }
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(m: MessageEntity) {
    val isUser = m.role == MessageRole.USER
    if (m.kind == MessageKind.TOOL_RESULT) {
        val (label, color) = when (m.outcome) {
            Outcome.SUCCESS -> "DONE · ${m.toolName}" to JarvisColors.Ok
            Outcome.HANDED_OFF -> "OPENED · ${m.toolName}" to JarvisColors.Warn
            Outcome.FAILED -> "FAILED · ${m.toolName}" to JarvisColors.Error
            Outcome.CANCELLED -> "CANCELLED · ${m.toolName}" to JarvisColors.TextDim
            else -> "WAITING · ${m.toolName}" to JarvisColors.Cyan
        }
        Bubble(text = m.text, label = label, labelColor = color, isUser = false)
    } else if (m.kind == MessageKind.NOTICE) {
        Bubble(text = m.text, label = "J.A.R.V.I.S.", labelColor = JarvisColors.Cyan, isUser = false)
    } else {
        Bubble(text = m.text, label = null, labelColor = Color.Unspecified, isUser = isUser)
    }
}

@Composable
private fun Bubble(text: String, label: String?, labelColor: Color, isUser: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (isUser) JarvisColors.Cyan.copy(alpha = 0.16f) else JarvisColors.Surface,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier.widthIn(max = 320.dp),
        ) {
            Column(Modifier.padding(12.dp)) {
                if (label != null) {
                    Text(label, style = MaterialTheme.typography.labelSmall, color = labelColor, fontWeight = FontWeight.SemiBold)
                }
                Text(text)
            }
        }
    }
}
