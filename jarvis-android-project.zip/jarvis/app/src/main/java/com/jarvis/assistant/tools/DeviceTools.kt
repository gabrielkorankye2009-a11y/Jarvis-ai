package com.jarvis.assistant.tools

import android.app.ActivityManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.Settings
import android.text.format.Formatter
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToInt

object DeviceTools {
    fun create(context: Context): List<Tool> {
        val app = context.applicationContext
        return listOf(
            BatteryTool(app), StorageTool(app), DeviceInfoTool(app), NetworkStatusTool(app),
            FlashlightTool(app), VolumeTool(app), OpenSettingsTool(app), TimerTool(app), AlarmTool(app),
            OpenAppTool(app), ClipboardCopyTool(app),
        )
    }
}

/** Starts an activity from a non-activity context. Returns the failure, or null if the system accepted the intent. */
internal fun Context.launchSafely(intent: Intent): Throwable? = try {
    startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    null
} catch (e: ActivityNotFoundException) {
    e
} catch (e: SecurityException) {
    e
}

data class BatterySnapshot(val percent: Int, val charging: Boolean)

object BatteryReader {
    fun read(context: Context): BatterySnapshot? {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level < 0 || scale <= 0) return null
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return BatterySnapshot(level * 100 / scale, charging)
    }
}

data class NetworkSnapshot(val airplaneMode: Boolean, val hasInternet: Boolean, val transports: List<String>)

object NetworkReader {
    fun read(context: Context): NetworkSnapshot {
        val airplane = Settings.Global.getInt(context.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) != 0
        val cm = context.getSystemService(ConnectivityManager::class.java)
        val network = cm?.activeNetwork
        val caps = if (cm != null && network != null) cm.getNetworkCapabilities(network) else null
        val transports = buildList {
            if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) add("Wi-Fi")
            if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true) add("mobile data")
            if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true) add("Ethernet")
            if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) add("VPN")
        }
        val internet = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        return NetworkSnapshot(airplane, internet, transports)
    }
}

class BatteryTool(private val context: Context) : Tool {
    override val spec = ToolSpecs.battery
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val s = BatteryReader.read(context)
            ?: return ToolResult.Failure("Android did not report battery information.")
        return ToolResult.Success("Battery is at ${s.percent}% and ${if (s.charging) "charging" else "not charging"}.")
    }
}

class StorageTool(private val context: Context) : Tool {
    override val spec = ToolSpecs.storage
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val stat = StatFs(Environment.getDataDirectory().path)
        val free = Formatter.formatFileSize(context, stat.availableBytes)
        val total = Formatter.formatFileSize(context, stat.totalBytes)
        return ToolResult.Success("$free free of $total internal storage.")
    }
}

class DeviceInfoTool(private val context: Context) : Tool {
    override val spec = ToolSpecs.deviceInfo
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val am = context.getSystemService(ActivityManager::class.java)
        val mem = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(mem)
        val ram = if (mem.totalMem > 0) Formatter.formatFileSize(context, mem.totalMem) else "unknown"
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        return ToolResult.Success(
            "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), CPU $abi, RAM $ram.",
        )
    }
}

class NetworkStatusTool(private val context: Context) : Tool {
    override val spec = ToolSpecs.network
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val n = NetworkReader.read(context)
        val state = when {
            n.airplaneMode -> "Airplane mode is on."
            n.hasInternet -> "You are online via ${n.transports.joinToString(" and ").ifEmpty { "an unknown network" }}."
            n.transports.isNotEmpty() -> "Connected to ${n.transports.joinToString(" and ")}, but Android reports no working internet."
            else -> "No network connection."
        }
        return ToolResult.Success(state)
    }
}

class FlashlightTool(private val context: Context) : Tool {
    override val spec = ToolSpecs.flashlight

    override suspend fun execute(args: Map<String, String>): ToolResult {
        val on = args["state"] == "on"
        val cm = context.getSystemService(CameraManager::class.java)
            ?: return ToolResult.Failure("The camera service is unavailable.")
        val id = flashCameraId(cm) ?: return ToolResult.Failure("This device reports no flashlight.")
        return if (setAndConfirm(cm, id, on)) {
            ToolResult.Success("Flashlight is ${if (on) "on" else "off"}.")
        } else {
            ToolResult.Failure(
                "I asked the camera service to turn the flashlight ${if (on) "on" else "off"} " +
                    "but did not get confirmation. Another app may be using the camera.",
            )
        }
    }

    private fun flashCameraId(cm: CameraManager): String? {
        val withFlash = cm.cameraIdList.filter { id ->
            cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        return withFlash.firstOrNull { id ->
            cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: withFlash.firstOrNull()
    }

    /** Sets the torch, then waits for the platform's own state callback to confirm it. */
    private suspend fun setAndConfirm(cm: CameraManager, id: String, on: Boolean): Boolean {
        var callback: CameraManager.TorchCallback? = null
        return try {
            withTimeoutOrNull(2_000) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    val cb = object : CameraManager.TorchCallback() {
                        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                            if (cameraId == id && enabled == on && cont.isActive) cont.resume(true)
                        }
                    }
                    callback = cb
                    cm.registerTorchCallback(cb, Handler(Looper.getMainLooper()))
                    try {
                        cm.setTorchMode(id, on)
                    } catch (e: Exception) {
                        if (cont.isActive) cont.resumeWithException(e)
                    }
                }
            } ?: false
        } finally {
            callback?.let { cm.unregisterTorchCallback(it) }
        }
    }
}

class VolumeTool(private val context: Context) : Tool {
    override val spec = ToolSpecs.volume
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val percent = args.getValue("percent").toInt()
        val am = context.getSystemService(AudioManager::class.java)
            ?: return ToolResult.Failure("The audio service is unavailable.")
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = (percent / 100.0 * max).roundToInt().coerceIn(0, max)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
        val actual = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        return if (actual == target) {
            ToolResult.Success("Media volume set to ${actual * 100 / max}% (level $actual of $max).")
        } else {
            ToolResult.Failure("I tried to set media volume to level $target but Android reports level $actual.")
        }
    }
}

class OpenSettingsTool(private val context: Context) : Tool {
    override val spec = ToolSpecs.openSettings

    override suspend fun execute(args: Map<String, String>): ToolResult {
        val screen = args.getValue("screen")
        val intent = when (screen) {
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "sound" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "battery_saver" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            "notifications" -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            else -> return ToolResult.Failure("Unknown settings screen '$screen'.")
        }
        val label = screen.replace('_', ' ')
        val error = context.launchSafely(intent)
        return if (error == null) {
            ToolResult.HandedOff("Opened the $label settings screen. Android does not let apps change this setting, so you will need to do it there.")
        } else {
            ToolResult.Failure("This device has no $label settings screen I can open.")
        }
    }
}

class TimerTool(private val context: Context) : Tool {
    override val spec = ToolSpecs.timer
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val seconds = args.getValue("seconds").toInt()
        val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "J.A.R.V.I.S.")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val label = Format.duration(seconds)
        return if (context.launchSafely(intent) == null) {
            ToolResult.HandedOff("Asked your clock app to start a $label timer. I cannot confirm it is running, so check your clock app.")
        } else {
            ToolResult.Failure("No clock app on this device accepted the timer request.")
        }
    }
}

class AlarmTool(private val context: Context) : Tool {
    override val spec = ToolSpecs.alarm
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val hour = args.getValue("hour").toInt()
        val minute = args.getValue("minute").toInt()
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, args["label"] ?: "J.A.R.V.I.S.")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val time = Format.clock(hour, minute)
        return if (context.launchSafely(intent) == null) {
            ToolResult.HandedOff("Asked your clock app to set an alarm for $time. I cannot confirm it was saved, so check your clock app.")
        } else {
            ToolResult.Failure("No clock app on this device accepted the alarm request.")
        }
    }
}

class OpenAppTool(private val context: Context) : Tool {
    override val spec = ToolSpecs.openApp

    @Suppress("DEPRECATION")
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val wanted = args.getValue("app_name").trim()
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
        val exact = apps.filter { it.first.equals(wanted, ignoreCase = true) }
        val matches = exact.ifEmpty { apps.filter { it.first.contains(wanted, ignoreCase = true) } }
        if (matches.isEmpty()) return ToolResult.Failure("I couldn't find an app called '$wanted'.")
        if (matches.size > 1) {
            val names = matches.take(5).joinToString(", ") { it.first }
            return ToolResult.Failure("Several apps match '$wanted': $names. Which one do you mean?")
        }
        val (label, pkg) = matches.first()
        val launch = pm.getLaunchIntentForPackage(pkg)
            ?: return ToolResult.Failure("$label has no launchable screen.")
        return if (context.launchSafely(launch) == null) {
            ToolResult.Success("Opened $label.")
        } else {
            ToolResult.Failure("Android would not let me open $label.")
        }
    }
}

class ClipboardCopyTool(private val context: Context) : Tool {
    override val spec = ToolSpecs.clipboard

    override fun confirmationPrompt(args: Map<String, String>): String =
        "Copy this text to the clipboard?\n\n\"${args["text"].orEmpty().take(200)}\""

    override suspend fun execute(args: Map<String, String>): ToolResult {
        val text = args.getValue("text")
        val cm = context.getSystemService(ClipboardManager::class.java)
            ?: return ToolResult.Failure("The clipboard service is unavailable.")
        cm.setPrimaryClip(ClipData.newPlainText("J.A.R.V.I.S.", text))
        val readBack = cm.primaryClip?.getItemAt(0)?.text?.toString()
        return if (readBack == text) {
            ToolResult.Success("Copied ${text.length} characters to the clipboard.")
        } else {
            ToolResult.Failure("I asked Android to copy the text but could not confirm it.")
        }
    }
}
