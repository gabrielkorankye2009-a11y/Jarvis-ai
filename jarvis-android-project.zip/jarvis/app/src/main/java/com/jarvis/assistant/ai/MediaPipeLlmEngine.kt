package com.jarvis.assistant.ai

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext
import java.io.File

/**
 * On-device inference through MediaPipe's LLM Inference API.
 *
 * UNVERIFIED: written from memory of the API without being able to compile against it. The version in
 * libs.versions.toml and the calls below (LlmInferenceOptions.builder, createFromOptions, generateResponseAsync
 * with a progress listener) must be confirmed by the first CI build. Google has also been moving this
 * functionality towards LiteRT-LM; that backend is not integrated yet.
 *
 * Models must be in MediaPipe's .task (or older .bin) format.
 */
class MediaPipeLlmEngine(private val context: Context) : LlmEngine {
    override val backendName = "MediaPipe LLM Inference"
    override val supportedExtensions = setOf("task", "bin")

    @Volatile
    private var llm: LlmInference? = null

    override val isLoaded: Boolean get() = llm != null

    override suspend fun load(modelFile: File, maxTokens: Int) {
        withContext(Dispatchers.Default) {
            unload()
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelFile.absolutePath)
                .setMaxTokens(maxTokens)
                .build()
            llm = LlmInference.createFromOptions(context, options)
        }
    }

    override fun generate(prompt: String): Flow<String> = callbackFlow {
        val engine = llm ?: throw IllegalStateException("No model is loaded.")
        engine.generateResponseAsync(prompt) { partial, done ->
            if (partial != null) trySend(partial)
            if (done) close()
        }
        awaitClose { }
    }.buffer(Channel.UNLIMITED)

    override fun unload() {
        llm?.close()
        llm = null
    }
}
