package com.jarvis.assistant.registry

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class Capability(
    val id: String,
    val name: String,
    val domain: String,
    val domainTitle: String,
    val module: String,
    val description: String,
    val permissions: List<String> = emptyList(),
    val offlineClass: String,
    val androidApis: String = "",
    val implementationStatus: String,
    val testingStatus: String,
    val acceptanceTest: String,
    val origin: String = "",
)

@Serializable
data class CapabilityRegistryFile(
    val schemaVersion: Int,
    val count: Int,
    val capabilities: List<Capability>,
)

object CapabilityRegistry {
    const val ASSET_NAME = "capability_registry.json"
    private val json = Json { ignoreUnknownKeys = true }

    fun parse(text: String): CapabilityRegistryFile =
        json.decodeFromString(CapabilityRegistryFile.serializer(), text)
}

/** Loads the bundled registry once and caches it. */
class CapabilityRepository(private val context: Context) {
    @Volatile
    private var cache: CapabilityRegistryFile? = null

    suspend fun load(): CapabilityRegistryFile {
        cache?.let { return it }
        return withContext(Dispatchers.IO) {
            val text = context.assets.open(CapabilityRegistry.ASSET_NAME).bufferedReader().use { it.readText() }
            CapabilityRegistry.parse(text).also { cache = it }
        }
    }
}
