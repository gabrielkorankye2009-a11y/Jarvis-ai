package com.jarvis.assistant.models

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.StatFs
import java.io.File
import java.util.Locale

data class DeviceCapabilities(
    val totalRamBytes: Long,
    val availRamBytes: Long,
    val freeStorageBytes: Long,
    val abis: List<String>,
    val sdkInt: Int,
    val cpuCores: Int,
) {
    val is64Bit: Boolean get() = abis.any { it == "arm64-v8a" || it == "x86_64" }
}

object DeviceCapabilitiesReader {
    fun read(context: Context, modelsDir: File): DeviceCapabilities {
        val am = context.getSystemService(ActivityManager::class.java)
        val mem = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(mem)
        val free = try {
            StatFs(modelsDir.path).availableBytes
        } catch (e: Exception) {
            0L
        }
        return DeviceCapabilities(
            totalRamBytes = mem.totalMem,
            availRamBytes = mem.availMem,
            freeStorageBytes = free,
            abis = Build.SUPPORTED_ABIS.toList(),
            sdkInt = Build.VERSION.SDK_INT,
            cpuCores = Runtime.getRuntime().availableProcessors(),
        )
    }
}

enum class ProfileTier(val label: String, val blurb: String) {
    LITE("Lite", "Fast replies and everyday commands. Small quantised models."),
    BALANCED("Balanced", "Better conversation and reasoning. Medium quantised models."),
    ADVANCED("Advanced", "Strongest model this device is likely to hold in memory."),
}

data class Recommendation(val tier: ProfileTier, val maxModelBytes: Long, val notes: List<String>)

sealed interface LoadVerdict {
    data class Ok(val warning: String? = null) : LoadVerdict
    data class Refuse(val reason: String) : LoadVerdict
}

/**
 * RAM-based heuristics only. These are starting points, not benchmarks: real speed and memory use
 * depend on the model, the runtime and what else is running. The Models screen offers a measured benchmark.
 */
object ModelRecommender {
    private const val GB = 1024L * 1024L * 1024L
    private const val MB = 1024L * 1024L

    fun recommend(c: DeviceCapabilities): Recommendation {
        val gb = c.totalRamBytes.toDouble() / GB
        val tier = when {
            !c.is64Bit || gb < 5.0 -> ProfileTier.LITE
            gb < 9.5 -> ProfileTier.BALANCED
            else -> ProfileTier.ADVANCED
        }
        val fraction = when (tier) {
            ProfileTier.LITE -> 0.30
            ProfileTier.BALANCED -> 0.35
            ProfileTier.ADVANCED -> 0.40
        }
        val notes = buildList {
            add("Heuristic from RAM only (${formatBytes(c.totalRamBytes)} total). Run the benchmark for measured speed.")
            if (!c.is64Bit) add("This device reports no 64-bit ABI; large models are unlikely to load.")
        }
        return Recommendation(tier, (c.totalRamBytes * fraction).toLong(), notes)
    }

    /** Refuses only when a model can never fit; warns when it exceeds the RAM that is free right now. */
    fun canLoad(modelBytes: Long, c: DeviceCapabilities): LoadVerdict {
        val needed = (modelBytes * 1.2).toLong()
        if (needed > (c.totalRamBytes * 0.8).toLong()) {
            return LoadVerdict.Refuse(
                "This model needs about ${formatBytes(needed)} of memory but the device has ${formatBytes(c.totalRamBytes)} in total. " +
                    "Choose a smaller or more heavily quantised model.",
            )
        }
        if (needed > c.availRamBytes) {
            return LoadVerdict.Ok(
                "Only ${formatBytes(c.availRamBytes)} of RAM is free and this model needs about ${formatBytes(needed)}. " +
                    "Close other apps if loading fails.",
            )
        }
        return LoadVerdict.Ok()
    }

    /**
     * Installed models in the order they should be tried: those within the suggested size for this device first
     * (largest first), then bigger ones (smallest first). Files the backend cannot load are excluded.
     */
    fun rankInstalled(models: List<ModelFile>, c: DeviceCapabilities, extensions: Set<String>): List<ModelFile> {
        val limit = recommend(c).maxModelBytes
        val usable = models.filter { it.name.substringAfterLast('.', "").lowercase() in extensions }
        val (fits, tooBig) = usable.partition { it.bytes <= limit }
        return fits.sortedByDescending { it.bytes } + tooBig.sortedBy { it.bytes }
    }

    fun hasStorageFor(modelBytes: Long, c: DeviceCapabilities): Boolean = c.freeStorageBytes >= modelBytes + 200 * MB

    fun formatBytes(bytes: Long): String = if (bytes >= GB) {
        String.format(Locale.ROOT, "%.1f GB", bytes.toDouble() / GB)
    } else {
        String.format(Locale.ROOT, "%d MB", bytes / MB)
    }
}
