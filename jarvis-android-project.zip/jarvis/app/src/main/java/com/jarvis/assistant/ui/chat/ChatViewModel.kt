package com.jarvis.assistant.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.AppContainer
import com.jarvis.assistant.ai.AssistantEvent
import com.jarvis.assistant.ai.ChatTurn
import com.jarvis.assistant.ai.Role
import com.jarvis.assistant.data.ConversationEntity
import com.jarvis.assistant.data.MessageEntity
import com.jarvis.assistant.data.MessageKind
import com.jarvis.assistant.data.MessageRole
import com.jarvis.assistant.data.Outcome
import com.jarvis.assistant.tools.ToolResult
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.cancellation.CancellationException

data class PendingAction(val tool: String, val args: Map<String, String>, val prompt: String)

data class ChatUiState(
    val conversationId: Long? = null,
    val messages: List<MessageEntity> = emptyList(),
    val conversations: List<ConversationEntity> = emptyList(),
    val streaming: String? = null,
    val busy: Boolean = false,
    val pending: PendingAction? = null,
)

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(private val container: AppContainer) : ViewModel() {
    private val repo = container.chatRepository
    private val currentId = MutableStateFlow<Long?>(null)
    private val streaming = MutableStateFlow<String?>(null)
    private val busy = MutableStateFlow(false)
    private val pending = MutableStateFlow<PendingAction?>(null)
    private var job: Job? = null

    private val messages = currentId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else repo.observeMessages(id)
    }
    private val stored = combine(currentId, messages, repo.observeConversations()) { id, m, c -> Triple(id, m, c) }
    private val liveState = combine(streaming, busy, pending) { s, b, p -> Triple(s, b, p) }

    val ui: StateFlow<ChatUiState> = combine(stored, liveState) { st, tr ->
        ChatUiState(
            conversationId = st.first, messages = st.second, conversations = st.third,
            streaming = tr.first, busy = tr.second, pending = tr.third,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ChatUiState())

    fun send(text: String) {
        val message = text.trim()
        if (message.isEmpty() || busy.value) return
        job = viewModelScope.launch {
            busy.value = true
            var partial = ""
            var activeId: Long? = null
            try {
                val id = currentId.value ?: repo.createConversation(message.take(40)).also { currentId.value = it }
                activeId = id
                repo.addMessage(id, MessageRole.USER, MessageKind.TEXT, message)
                val history = toTurns(repo.getMessages(id))
                container.orchestrator.handle(message, history).collect { event ->
                    if (event is AssistantEvent.Partial) {
                        partial = event.text
                        streaming.value = event.text
                    } else {
                        streaming.value = null
                        partial = ""
                        persist(id, event)
                    }
                }
            } catch (e: CancellationException) {
                val id = activeId
                if (id != null && partial.isNotBlank()) {
                    withContext(NonCancellable) {
                        repo.addMessage(id, MessageRole.ASSISTANT, MessageKind.TEXT, partial.trim() + " [stopped]")
                    }
                }
                throw e
            } catch (e: Exception) {
                val id = activeId
                if (id != null) {
                    repo.addMessage(
                        id, MessageRole.ASSISTANT, MessageKind.NOTICE,
                        "Something went wrong: ${e.message ?: e.javaClass.simpleName}",
                    )
                }
            } finally {
                streaming.value = null
                busy.value = false
            }
        }
    }

    fun stop() {
        job?.cancel()
    }

    fun confirmPending() {
        val action = pending.value ?: return
        pending.value = null
        val id = currentId.value ?: return
        viewModelScope.launch {
            busy.value = true
            try {
                persist(id, container.orchestrator.runConfirmed(action.tool, action.args))
            } finally {
                busy.value = false
            }
        }
    }

    fun cancelPending() {
        val action = pending.value ?: return
        pending.value = null
        val id = currentId.value ?: return
        viewModelScope.launch {
            repo.addMessage(
                id, MessageRole.ASSISTANT, MessageKind.TOOL_RESULT,
                "Cancelled. I did not run ${action.tool}.", action.tool, Outcome.CANCELLED,
            )
        }
    }

    fun newConversation() {
        if (!busy.value) currentId.value = null
    }

    fun select(conversationId: Long) {
        if (!busy.value) currentId.value = conversationId
    }

    fun delete(conversationId: Long) {
        if (busy.value) return
        viewModelScope.launch {
            if (currentId.value == conversationId) currentId.value = null
            repo.deleteConversation(conversationId)
        }
    }

    private suspend fun persist(id: Long, event: AssistantEvent) {
        when (event) {
            is AssistantEvent.Partial -> Unit
            is AssistantEvent.Final -> repo.addMessage(id, MessageRole.ASSISTANT, MessageKind.TEXT, event.text)
            is AssistantEvent.Notice -> repo.addMessage(id, MessageRole.ASSISTANT, MessageKind.NOTICE, event.text)
            is AssistantEvent.ToolOutcome -> repo.addMessage(
                id, MessageRole.ASSISTANT, MessageKind.TOOL_RESULT, event.result.message, event.tool, outcomeOf(event.result),
            )
            is AssistantEvent.NeedsConfirmation -> {
                pending.value = PendingAction(event.tool, event.args, event.prompt)
                repo.addMessage(
                    id, MessageRole.ASSISTANT, MessageKind.TOOL_RESULT,
                    "Waiting for your confirmation before running ${event.tool}.", event.tool, Outcome.PENDING,
                )
            }
        }
    }

    private fun outcomeOf(result: ToolResult): String = when (result) {
        is ToolResult.Success -> Outcome.SUCCESS
        is ToolResult.HandedOff -> Outcome.HANDED_OFF
        is ToolResult.Failure -> Outcome.FAILED
    }

    /**
     * Only plain conversation text goes to the model. Tool results and app notices are left out so the
     * model cannot imitate them and present invented results as real ones.
     */
    private fun toTurns(stored: List<MessageEntity>): List<ChatTurn> = stored
        .filter { it.kind == MessageKind.TEXT }
        .map { ChatTurn(if (it.role == MessageRole.USER) Role.USER else Role.ASSISTANT, it.text) }
}
