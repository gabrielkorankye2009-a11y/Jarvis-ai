package com.jarvis.assistant.models

import com.jarvis.assistant.AppSettings
import com.jarvis.assistant.ai.ChatTurn
import com.jarvis.assistant.ai.LlmEngine
import com.jarvis.assistant.ai.ModelRunner
import com.jarvis.assistant.ai.ModelUnavailableException
import com.jarvis.assistant.ai.PromptBuilder
import com.jarvis.assistant.ai.Role
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.cancellation.CancellationException

data class BenchmarkResult(val firstChunkMs: Long, val totalMs: Long, val chars: Int) {
    val charsPerSecond: Double get() = if (totalMs <= 0) 0.0 else chars * 1000.0 / totalMs
}

data class ModelManagerState(
    val models: List<ModelFile> = emptyList(),
    val activeModel: String? = null,
    val loadedModel: String? = null,
    val loading: Boolean = false,
    val lastError: String? = null,
    val notice: String? = null,
    val benchmark: BenchmarkResult? = null,
)

/**
 * Owns the lifecycle of the loaded model: lazy loading, memory checks, serialised load/unload,
 * and automatic unloading after a period of inactivity so the model does not hold RAM needlessly.
 */
class ModelManager(
    private val engine: LlmEngine,
    private val store: ModelStore,
    private val settings: AppSettings,
    private val scope: CoroutineScope,
    private val capabilities: () -> DeviceCapabilities,
    private val idleUnloadMs: Long = 5 * 60 * 1000L,
) : ModelRunner {
    private val _state = MutableStateFlow(ModelManagerState())
    val state: StateFlow<ModelManagerState> = _state.asStateFlow()

    private val mutex = Mutex()
    private val inUse = AtomicInteger(0)
    private var idleJob: Job? = null

    val backendName: String get() = engine.backendName
    val supportedExtensions: Set<String> get() = engine.supportedExtensions

    init {
        refresh()
    }

    fun refresh() {
        _state.update {
            it.copy(
                models = store.list(),
                activeModel = settings.activeModel,
                loadedModel = if (engine.isLoaded) it.loadedModel else null,
            )
        }
    }

    fun selectActive(name: String?) {
        settings.activeModel = name
        refresh()
    }

    /**
     * Loads a model if none is loaded. With no (valid) selection it picks the best installed model for this
     * device. If the selected model fails to load it falls back to the smallest installed model that is
     * lighter than the one that failed, and says so in [ModelManagerState.notice].
     */
    suspend fun ensureLoaded(): Result<Unit> = mutex.withLock {
        if (engine.isLoaded) return@withLock Result.success(Unit)
        val ranked = ModelRecommender.rankInstalled(store.list(), capabilities(), engine.supportedExtensions)
        val chosen = settings.activeModel?.takeIf { store.file(it) != null }
        if (chosen == null) {
            val auto = ranked.firstOrNull() ?: return@withLock fail(
                "No usable model is installed. Open the Models tab to import or download one.",
            )
            selectActive(auto.name)
            val result = loadLocked(auto.name)
            if (result.isSuccess) {
                _state.update {
                    it.copy(notice = "Selected ${auto.name} automatically: the largest installed model that suits this device.")
                }
            }
            return@withLock result
        }
        val first = loadLocked(chosen)
        if (first.isSuccess) return@withLock first
        val failedBytes = store.file(chosen)?.length() ?: Long.MAX_VALUE
        val lighter = ranked.filter { it.name != chosen && it.bytes < failedBytes }.minByOrNull { it.bytes }
            ?: return@withLock first
        val second = loadLocked(lighter.name)
        if (second.isSuccess) {
            selectActive(lighter.name)
            _state.update { it.copy(notice = "$chosen could not be loaded, so I switched to the lighter ${lighter.name}.") }
        }
        second
    }

    suspend fun load(name: String): Result<Unit> = mutex.withLock {
        if (inUse.get() > 0) return@withLock fail("The model is busy generating a reply.")
        selectActive(name)
        if (engine.isLoaded) unloadLocked()
        loadLocked(name)
    }

    /** Returns false if the model is busy and was not unloaded. */
    suspend fun unload(): Boolean = mutex.withLock {
        if (inUse.get() > 0) {
            false
        } else {
            unloadLocked()
            true
        }
    }

    /** Runs [block] with a loaded engine, loading it first if needed. Throws [ModelUnavailableException] on failure. */
    override suspend fun <T> use(block: suspend (LlmEngine) -> T): T {
        ensureLoaded().getOrThrow()
        inUse.incrementAndGet()
        idleJob?.cancel()
        try {
            return block(engine)
        } finally {
            if (inUse.decrementAndGet() == 0) scheduleIdleUnload()
        }
    }

    suspend fun benchmark(): Result<BenchmarkResult> = try {
        val result = use { eng ->
            val prompt = PromptBuilder.build(
                settings.promptTemplate,
                "You are a concise assistant.",
                listOf(ChatTurn(Role.USER, "List the numbers from 1 to 30 separated by commas.")),
                maxChars = 2_000,
            )
            val start = System.nanoTime()
            var first = -1L
            var chars = 0
            eng.generate(prompt).collect { chunk ->
                if (first < 0) first = (System.nanoTime() - start) / 1_000_000
                chars += chunk.length
            }
            BenchmarkResult(first.coerceAtLeast(0), (System.nanoTime() - start) / 1_000_000, chars)
        }
        _state.update { it.copy(benchmark = result) }
        Result.success(result)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Result.failure(e)
    }

    private fun fail(message: String): Result<Unit> {
        _state.update { it.copy(loading = false, lastError = message) }
        return Result.failure(ModelUnavailableException(message))
    }

    private suspend fun loadLocked(name: String): Result<Unit> {
        val file = store.file(name) ?: return fail("The model file '$name' is missing. Import it again.")
        val ext = file.extension.lowercase()
        if (ext !in engine.supportedExtensions) {
            return fail(
                "The ${engine.backendName} backend cannot load .$ext files. " +
                    "Supported: ${engine.supportedExtensions.joinToString { ".$it" }}.",
            )
        }
        var warning: String? = null
        when (val verdict = ModelRecommender.canLoad(file.length(), capabilities())) {
            is LoadVerdict.Refuse -> return fail(verdict.reason)
            is LoadVerdict.Ok -> warning = verdict.warning
        }
        _state.update { it.copy(loading = true, lastError = null, notice = warning) }
        return try {
            engine.load(file, settings.maxTokens)
            _state.update { it.copy(loading = false, loadedModel = name) }
            Result.success(Unit)
        } catch (e: CancellationException) {
            _state.update { it.copy(loading = false) }
            throw e
        } catch (t: Throwable) {
            fail("Could not load '$name': ${t.message ?: t.javaClass.simpleName}")
        }
    }

    private fun unloadLocked() {
        engine.unload()
        _state.update { it.copy(loadedModel = null) }
    }

    private fun scheduleIdleUnload() {
        idleJob?.cancel()
        idleJob = scope.launch {
            delay(idleUnloadMs)
            mutex.withLock { if (inUse.get() == 0 && engine.isLoaded) unloadLocked() }
        }
    }
}
