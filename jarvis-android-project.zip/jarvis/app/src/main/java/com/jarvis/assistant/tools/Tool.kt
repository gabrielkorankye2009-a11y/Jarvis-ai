package com.jarvis.assistant.tools

import kotlin.coroutines.cancellation.CancellationException

interface Tool {
    val spec: ToolSpec
    suspend fun execute(args: Map<String, String>): ToolResult
    fun confirmationPrompt(args: Map<String, String>): String = "Run ${spec.name} with $args?"
}

class ToolRegistry(tools: List<Tool>) {
    private val byName = tools.associateBy { it.spec.name }
    fun get(name: String): Tool? = byName[name]
    fun specs(): List<ToolSpec> = byName.values.map { it.spec }
}

class ToolExecutor(private val registry: ToolRegistry) {
    sealed interface Prepared {
        data class Ready(val tool: Tool, val args: Map<String, String>) : Prepared
        data class Rejected(val result: ToolResult.Failure) : Prepared
    }

    /** Looks up the tool and validates arguments. Nothing is executed here. */
    fun prepare(name: String, raw: Map<String, String>): Prepared {
        val tool = registry.get(name)
            ?: return Prepared.Rejected(ToolResult.Failure("I don't have a tool called '$name'."))
        return when (val v = ToolValidator.validate(tool.spec, raw)) {
            is ToolValidator.Validation.Valid -> Prepared.Ready(tool, v.args)
            is ToolValidator.Validation.Invalid -> Prepared.Rejected(ToolResult.Failure(v.reason))
        }
    }

    suspend fun run(tool: Tool, args: Map<String, String>): ToolResult = try {
        tool.execute(args)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        ToolResult.Failure("${tool.spec.name} failed: ${e.message ?: e.javaClass.simpleName}")
    }
}
