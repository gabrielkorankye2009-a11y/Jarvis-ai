package com.jarvis.assistant.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

object MessageRole {
    const val USER = "user"
    const val ASSISTANT = "assistant"
}

object MessageKind {
    /** Ordinary conversation text. */
    const val TEXT = "text"

    /** Result of a tool run. The text comes from the tool, not from the model. */
    const val TOOL_RESULT = "tool_result"

    /** App-generated notice (clarification, missing model). Not part of the model's context. */
    const val NOTICE = "notice"
}

object Outcome {
    const val SUCCESS = "SUCCESS"
    const val HANDED_OFF = "HANDED_OFF"
    const val FAILED = "FAILED"
    const val PENDING = "PENDING"
    const val CANCELLED = "CANCELLED"
}

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
)

@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity = ConversationEntity::class,
            parentColumns = ["id"],
            childColumns = ["conversationId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("conversationId")],
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: Long,
    val role: String,
    val kind: String,
    val text: String,
    val toolName: String? = null,
    val outcome: String? = null,
    val createdAt: Long,
)

@Dao
interface ChatDao {
    @Insert
    suspend fun insertConversation(conversation: ConversationEntity): Long

    @Insert
    suspend fun insertMessage(message: MessageEntity): Long

    @Query("UPDATE conversations SET updatedAt = :time WHERE id = :id")
    suspend fun touch(id: Long, time: Long)

    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC")
    fun observeConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM messages WHERE conversationId = :id ORDER BY id ASC")
    fun observeMessages(id: Long): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE conversationId = :id ORDER BY id ASC")
    suspend fun getMessages(id: Long): List<MessageEntity>

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun deleteConversation(id: Long)

    @Query("SELECT * FROM messages WHERE text LIKE '%' || :pattern || '%' ESCAPE '\\' ORDER BY id DESC LIMIT :limit")
    suspend fun searchMessages(pattern: String, limit: Int): List<MessageEntity>
}

@Database(entities = [ConversationEntity::class, MessageEntity::class], version = 1, exportSchema = false)
abstract class JarvisDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
}

class ChatRepository(private val dao: ChatDao, private val clock: () -> Long = System::currentTimeMillis) {
    fun observeConversations(): Flow<List<ConversationEntity>> = dao.observeConversations()
    fun observeMessages(conversationId: Long): Flow<List<MessageEntity>> = dao.observeMessages(conversationId)
    suspend fun getMessages(conversationId: Long): List<MessageEntity> = dao.getMessages(conversationId)

    suspend fun createConversation(title: String): Long {
        val now = clock()
        return dao.insertConversation(ConversationEntity(title = title, createdAt = now, updatedAt = now))
    }

    suspend fun addMessage(
        conversationId: Long,
        role: String,
        kind: String,
        text: String,
        toolName: String? = null,
        outcome: String? = null,
    ): Long {
        val now = clock()
        val id = dao.insertMessage(
            MessageEntity(
                conversationId = conversationId, role = role, kind = kind, text = text,
                toolName = toolName, outcome = outcome, createdAt = now,
            ),
        )
        dao.touch(conversationId, now)
        return id
    }

    suspend fun deleteConversation(conversationId: Long) = dao.deleteConversation(conversationId)

    /** Plain substring search; LIKE wildcards in [query] are escaped so they match literally. */
    suspend fun search(query: String, limit: Int = 50): List<MessageEntity> {
        val escaped = query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        return dao.searchMessages(escaped, limit)
    }
}
