package com.jarvis.assistant

import android.app.Application
import androidx.room.Room
import com.jarvis.assistant.ai.AssistantOrchestrator
import com.jarvis.assistant.ai.LlmEngine
import com.jarvis.assistant.ai.MediaPipeLlmEngine
import com.jarvis.assistant.data.ChatRepository
import com.jarvis.assistant.data.JarvisDatabase
import com.jarvis.assistant.models.DeviceCapabilitiesReader
import com.jarvis.assistant.models.ModelDownloader
import com.jarvis.assistant.models.ModelManager
import com.jarvis.assistant.models.ModelStore
import com.jarvis.assistant.registry.CapabilityRepository
import com.jarvis.assistant.tools.DeviceTools
import com.jarvis.assistant.tools.ToolExecutor
import com.jarvis.assistant.tools.ToolRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

/** Hand-wired dependency container. Everything heavy is lazy so cold start does nothing it does not need. */
class AppContainer(val app: Application, private val databaseName: String = "jarvis.db") {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val settings = AppSettings(app)

    val database: JarvisDatabase by lazy {
        Room.databaseBuilder(app, JarvisDatabase::class.java, databaseName).build()
    }
    val chatRepository: ChatRepository by lazy { ChatRepository(database.chatDao()) }
    val capabilityRepository = CapabilityRepository(app)

    val toolRegistry: ToolRegistry by lazy { ToolRegistry(DeviceTools.create(app)) }
    val toolExecutor: ToolExecutor by lazy { ToolExecutor(toolRegistry) }

    val modelStore = ModelStore(app)
    val modelDownloader = ModelDownloader(app)
    val engine: LlmEngine by lazy { MediaPipeLlmEngine(app) }
    val modelManager: ModelManager by lazy {
        ModelManager(
            engine = engine,
            store = modelStore,
            settings = settings,
            scope = appScope,
            capabilities = { DeviceCapabilitiesReader.read(app, modelStore.dir) },
        )
    }
    val orchestrator: AssistantOrchestrator by lazy {
        AssistantOrchestrator(toolRegistry, toolExecutor, modelManager, settings)
    }

    /** Releases the database, background work and the loaded model. Used by tests to simulate an app restart. */
    fun shutdown() {
        appScope.cancel()
        engine.unload()
        database.close()
    }
}
