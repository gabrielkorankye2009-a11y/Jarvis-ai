package com.jarvis.assistant

import android.content.Context
import com.jarvis.assistant.ai.AssistantConfig
import com.jarvis.assistant.ai.PromptTemplate

class AppSettings(context: Context) : AssistantConfig {
    private val prefs = context.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

    override var assistantName: String
        get() = prefs.getString(KEY_NAME, DEFAULT_NAME) ?: DEFAULT_NAME
        set(value) {
            prefs.edit().putString(KEY_NAME, value.trim().ifEmpty { DEFAULT_NAME }).apply()
        }

    var activeModel: String?
        get() = prefs.getString(KEY_MODEL, null)
        set(value) {
            val editor = prefs.edit()
            if (value == null) editor.remove(KEY_MODEL) else editor.putString(KEY_MODEL, value)
            editor.apply()
        }

    override var promptTemplate: PromptTemplate
        get() = runCatching { PromptTemplate.valueOf(prefs.getString(KEY_TEMPLATE, "") ?: "") }
            .getOrDefault(PromptTemplate.GEMMA)
        set(value) {
            prefs.edit().putString(KEY_TEMPLATE, value.name).apply()
        }

    /** Total context length (prompt plus reply) handed to the model runtime. */
    override var maxTokens: Int
        get() = prefs.getInt(KEY_MAX_TOKENS, 1024)
        set(value) {
            prefs.edit().putInt(KEY_MAX_TOKENS, value).apply()
        }

    var downloadWifiOnly: Boolean
        get() = prefs.getBoolean(KEY_WIFI_ONLY, true)
        set(value) {
            prefs.edit().putBoolean(KEY_WIFI_ONLY, value).apply()
        }

    companion object {
        const val DEFAULT_NAME = "J.A.R.V.I.S."
        private const val KEY_NAME = "assistant_name"
        private const val KEY_MODEL = "active_model"
        private const val KEY_TEMPLATE = "prompt_template"
        private const val KEY_MAX_TOKENS = "max_tokens"
        private const val KEY_WIFI_ONLY = "download_wifi_only"
    }
}
