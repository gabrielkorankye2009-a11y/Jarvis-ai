package com.jarvis.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object JarvisColors {
    val Cyan = Color(0xFF00E5FF)
    val Blue = Color(0xFF2979FF)
    val Background = Color(0xFF03060D)
    val Surface = Color(0xFF0A1226)
    val SurfaceHigh = Color(0xFF111B33)
    val Outline = Color(0xFF27406B)
    val Text = Color(0xFFE6F1FF)
    val TextDim = Color(0xFF9FB4D6)
    val Ok = Color(0xFF4CAF50)
    val Warn = Color(0xFFFFB300)
    val Error = Color(0xFFFF5252)
}

private val scheme = darkColorScheme(
    primary = JarvisColors.Cyan,
    onPrimary = Color(0xFF00131A),
    secondary = JarvisColors.Blue,
    background = JarvisColors.Background,
    onBackground = JarvisColors.Text,
    surface = JarvisColors.Surface,
    onSurface = JarvisColors.Text,
    surfaceVariant = JarvisColors.SurfaceHigh,
    onSurfaceVariant = JarvisColors.TextDim,
    outline = JarvisColors.Outline,
    error = JarvisColors.Error,
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
