package com.jarvis.assistant.ui.features

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.AppContainer
import com.jarvis.assistant.registry.Capability
import com.jarvis.assistant.ui.theme.JarvisColors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FeaturesUiState(
    val loading: Boolean = true,
    val error: String? = null,
    val all: List<Capability> = emptyList(),
    val query: String = "",
    val domain: String? = null,
    val onlyStarted: Boolean = false,
) {
    val visible: List<Capability>
        get() = all.filter { c ->
            (domain == null || c.domain == domain) &&
                (!onlyStarted || c.implementationStatus != "PLANNED") &&
                (
                    query.isBlank() || c.name.contains(query, ignoreCase = true) ||
                        c.id.contains(query, ignoreCase = true) || c.domainTitle.contains(query, ignoreCase = true)
                    )
        }
}

/** Reads the bundled 738-entry registry. Statuses shown are exactly what the registry file says. */
class FeaturesViewModel(container: AppContainer) : ViewModel() {
    private val _ui = MutableStateFlow(FeaturesUiState())
    val ui: StateFlow<FeaturesUiState> = _ui.asStateFlow()

    init {
        viewModelScope.launch {
            try {
                val registry = container.capabilityRepository.load()
                _ui.update { it.copy(loading = false, all = registry.capabilities) }
            } catch (e: Exception) {
                _ui.update { it.copy(loading = false, error = "Could not read the capability registry: ${e.message}") }
            }
        }
    }

    fun setQuery(q: String) = _ui.update { it.copy(query = q) }
    fun setDomain(d: String?) = _ui.update { it.copy(domain = d) }
    fun setOnlyStarted(v: Boolean) = _ui.update { it.copy(onlyStarted = v) }
}

@Composable
fun FeatureDirectoryScreen(vm: FeaturesViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var expanded by remember { mutableStateOf(setOf<String>()) }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Text(
            "Feature directory", style = MaterialTheme.typography.headlineSmall,
            color = JarvisColors.Cyan, modifier = Modifier.padding(top = 12.dp),
        )
        if (ui.loading) {
            Text("Loading registry…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            return@Column
        }
        ui.error?.let {
            Text(it, color = JarvisColors.Error)
            return@Column
        }
        val counts = ui.all.groupingBy { it.implementationStatus }.eachCount()
        Text(
            "${ui.all.size} capabilities · " + listOf("PLANNED", "IN DEVELOPMENT", "IMPLEMENTED", "TESTED", "VERIFIED ON DEVICE")
                .joinToString(" · ") { "$it ${counts[it] ?: 0}" },
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.labelMedium,
        )
        OutlinedTextField(
            value = ui.query, onValueChange = vm::setQuery, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            label = { Text("Search name, ID or domain") }, singleLine = true,
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = ui.onlyStarted, onClick = { vm.setOnlyStarted(!ui.onlyStarted) }, label = { Text("Has code") })
            FilterChip(selected = ui.domain == null, onClick = { vm.setDomain(null) }, label = { Text("All") })
            ui.all.map { it.domain }.distinct().sorted().forEach { d ->
                FilterChip(selected = ui.domain == d, onClick = { vm.setDomain(d) }, label = { Text(d) })
            }
        }
        val visible = ui.visible
        Text("${visible.size} shown", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
        LazyColumn(contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(visible, key = { it.id }) { c ->
                val open = c.id in expanded
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = JarvisColors.Surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth().clickable { expanded = if (open) expanded - c.id else expanded + c.id },
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(c.name, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${c.id} · ${c.offlineClass.replace('_', ' ')} · ${c.implementationStatus} · ${c.testingStatus.replace('_', ' ')}",
                            style = MaterialTheme.typography.labelSmall,
                            color = statusColor(c),
                        )
                        if (open) {
                            Text("Domain ${c.domain}: ${c.domainTitle}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Module: ${c.module}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Permissions: ${c.permissions.joinToString().ifEmpty { "none" }}")
                            Text("Android APIs: ${c.androidApis}")
                            Text("Acceptance test: ${c.acceptanceTest}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

private fun statusColor(c: Capability): Color = when (c.implementationStatus) {
    "PLANNED" -> JarvisColors.TextDim
    "IN DEVELOPMENT" -> JarvisColors.Warn
    else -> JarvisColors.Ok
}
