package com.jarvis.assistant.models

import android.app.DownloadManager
import android.content.Context
import android.net.Uri

data class DownloadProgress(val running: Boolean, val succeeded: Boolean, val failed: Boolean, val bytes: Long, val total: Long, val reason: Int)

/**
 * Starts downloads only when the user taps Download. No model catalogue is bundled: URLs for many
 * models are gated or change, and none have been verified from this build environment.
 */
class ModelDownloader(private val context: Context) {
    private val manager get() = context.getSystemService(DownloadManager::class.java)

    fun start(url: String, wifiOnly: Boolean): Result<Long> {
        val uri = try {
            Uri.parse(url.trim())
        } catch (e: Exception) {
            return Result.failure(IllegalArgumentException("That is not a valid URL."))
        }
        if (uri.scheme != "https") return Result.failure(IllegalArgumentException("Only https:// links are allowed."))
        val fileName = ModelStore.sanitize(uri.lastPathSegment ?: "model.bin")
        return try {
            val request = DownloadManager.Request(uri)
                .setTitle(fileName)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(!wifiOnly)
                .setDestinationInExternalFilesDir(context, "models", fileName)
            Result.success(manager.enqueue(request))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun progress(id: Long): DownloadProgress? {
        val cursor = manager.query(DownloadManager.Query().setFilterById(id)) ?: return null
        return cursor.use { c ->
            if (!c.moveToFirst()) {
                null
            } else {
                val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                DownloadProgress(
                    running = status == DownloadManager.STATUS_RUNNING || status == DownloadManager.STATUS_PENDING ||
                        status == DownloadManager.STATUS_PAUSED,
                    succeeded = status == DownloadManager.STATUS_SUCCESSFUL,
                    failed = status == DownloadManager.STATUS_FAILED,
                    bytes = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                    total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)),
                    reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)),
                )
            }
        }
    }

    fun cancel(id: Long) {
        manager.remove(id)
    }
}
