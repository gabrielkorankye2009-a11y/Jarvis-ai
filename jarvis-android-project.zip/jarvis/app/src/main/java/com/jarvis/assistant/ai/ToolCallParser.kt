package com.jarvis.assistant.ai

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

data class ParsedToolCall(val name: String, val args: Map<String, String>)

object ToolCallParser {
    private val block = Regex("""<tool_call>\s*(\{.*\})\s*(?:</tool_call>)?""", RegexOption.DOT_MATCHES_ALL)

    /** Returns the first well-formed tool call in [text], or null. Malformed output is treated as plain text. */
    fun parse(text: String): ParsedToolCall? {
        val match = block.find(text) ?: return null
        return try {
            val obj = Json.parseToJsonElement(match.groupValues[1]).jsonObject
            val name = obj["name"]?.jsonPrimitive?.content?.trim().orEmpty()
            if (name.isEmpty()) {
                null
            } else {
                val argsObj = obj["arguments"] as? JsonObject
                val args = argsObj?.mapValues { (_, v) -> if (v is JsonPrimitive) v.content else v.toString() }
                    ?: emptyMap()
                ParsedToolCall(name, args)
            }
        } catch (e: Exception) {
            null
        }
    }
}
