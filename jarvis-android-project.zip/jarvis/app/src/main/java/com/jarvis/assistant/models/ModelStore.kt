package com.jarvis.assistant.models

import android.content.Context
import android.net.Uri
import android.os.StatFs
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import kotlin.coroutines.cancellation.CancellationException

data class ModelFile(val name: String, val bytes: Long)

/** App-private model storage. Nothing here is readable by other apps on current Android versions. */
class ModelStore(private val context: Context) {
    val dir: File
        get() = (context.getExternalFilesDir("models") ?: File(context.filesDir, "models")).also { it.mkdirs() }

    fun list(): List<ModelFile> = dir.listFiles().orEmpty()
        .filter { it.isFile && !it.name.endsWith(".part") }
        .sortedBy { it.name }
        .map { ModelFile(it.name, it.length()) }

    fun file(name: String): File? {
        val f = File(dir, sanitize(name))
        return if (f.isFile) f else null
    }

    fun delete(name: String): Boolean = file(name)?.delete() ?: false

    /** Copies a user-selected file into model storage, reporting progress as (copiedBytes, totalBytes or -1). */
    suspend fun import(
        uri: Uri,
        allowedExtensions: Set<String>,
        onProgress: (Long, Long) -> Unit,
    ): Result<ModelFile> = withContext(Dispatchers.IO) {
        var part: File? = null
        try {
            var display: String? = null
            var size = -1L
            context.contentResolver.query(
                uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null,
            )?.use { c ->
                if (c.moveToFirst()) {
                    val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) display = c.getString(nameIdx)
                    if (sizeIdx >= 0 && !c.isNull(sizeIdx)) size = c.getLong(sizeIdx)
                }
            }
            val name = sanitize(display ?: "model.bin")
            val ext = name.substringAfterLast('.', "").lowercase()
            if (ext !in allowedExtensions) {
                return@withContext Result.failure(
                    IllegalArgumentException(
                        "'.$ext' files are not supported by the current backend. Supported: ${allowedExtensions.joinToString { ".$it" }}.",
                    ),
                )
            }
            val free = StatFs(dir.path).availableBytes
            if (size > 0 && free < size + 100L * 1024 * 1024) {
                return@withContext Result.failure(IOException("Not enough free storage to import this model."))
            }
            val input = context.contentResolver.openInputStream(uri)
                ?: return@withContext Result.failure(IOException("Could not open the selected file."))
            val partFile = File(dir, "$name.part")
            part = partFile
            input.use { src ->
                partFile.outputStream().use { dst ->
                    val buffer = ByteArray(1 shl 20)
                    var copied = 0L
                    while (true) {
                        val n = src.read(buffer)
                        if (n < 0) break
                        dst.write(buffer, 0, n)
                        copied += n
                        onProgress(copied, size)
                        ensureActive()
                    }
                }
            }
            val target = File(dir, name)
            if (target.exists()) target.delete()
            if (!partFile.renameTo(target)) {
                return@withContext Result.failure(IOException("Could not finalise the imported file."))
            }
            Result.success(ModelFile(target.name, target.length()))
        } catch (e: CancellationException) {
            part?.delete()
            throw e
        } catch (e: Exception) {
            part?.delete()
            Result.failure(e)
        }
    }

    companion object {
        fun sanitize(name: String): String =
            name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_").ifEmpty { "model.bin" }
    }
}
