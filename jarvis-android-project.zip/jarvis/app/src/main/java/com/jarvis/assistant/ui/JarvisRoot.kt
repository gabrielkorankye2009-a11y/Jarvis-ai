package com.jarvis.assistant.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.jarvis.assistant.AppContainer
import com.jarvis.assistant.ui.chat.ChatScreen
import com.jarvis.assistant.ui.chat.ChatViewModel
import com.jarvis.assistant.ui.features.FeatureDirectoryScreen
import com.jarvis.assistant.ui.features.FeaturesViewModel
import com.jarvis.assistant.ui.models.ModelsScreen
import com.jarvis.assistant.ui.models.ModelsViewModel

private data class Tab(val route: String, val label: String, val glyph: String)

private val tabs = listOf(
    Tab("chat", "Chat", "◉"),
    Tab("models", "Models", "▣"),
    Tab("features", "Features", "≡"),
)

@Composable
fun JarvisRoot(container: AppContainer) {
    // Activity-scoped so state survives tab switches.
    val chatVm: ChatViewModel = viewModel(factory = viewModelFactory { initializer { ChatViewModel(container) } })
    val modelsVm: ModelsViewModel = viewModel(factory = viewModelFactory { initializer { ModelsViewModel(container) } })
    val featuresVm: FeaturesViewModel = viewModel(factory = viewModelFactory { initializer { FeaturesViewModel(container) } })

    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = route == tab.route,
                        onClick = {
                            nav.navigate(tab.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Text(tab.glyph) },
                        label = { Text(tab.label) },
                    )
                }
            }
        },
    ) { padding ->
        NavHost(nav, startDestination = "chat", modifier = Modifier.padding(padding)) {
            composable("chat") { ChatScreen(chatVm, onOpenModels = { nav.navigate("models") }) }
            composable("models") { ModelsScreen(modelsVm) }
            composable("features") { FeatureDirectoryScreen(featuresVm) }
        }
    }
}
