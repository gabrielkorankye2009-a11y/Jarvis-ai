package com.jarvis.assistant.ai

import com.jarvis.assistant.tools.ToolExecutor
import com.jarvis.assistant.tools.ToolRegistry
import com.jarvis.assistant.tools.ToolResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

sealed interface AssistantEvent {
    /** Reply text so far. UI-only; nothing is stored until [Final] arrives. */
    data class Partial(val text: String) : AssistantEvent

    data class Final(val text: String) : AssistantEvent

    /** Real result of a tool run, produced by the tool and not by the model. */
    data class ToolOutcome(val tool: String, val result: ToolResult) : AssistantEvent

    data class NeedsConfirmation(val tool: String, val args: Map<String, String>, val prompt: String) : AssistantEvent

    /** App-generated message such as a clarifying question or a missing-model notice. */
    data class Notice(val text: String) : AssistantEvent
}

/**
 * Request pipeline:
 * 1. Deterministic router for known device commands (works with no model).
 * 2. Otherwise the local model, prompted with the tool list.
 * 3. If the model asks for a tool, the call is validated and executed here, and only the tool's real
 *    result is shown. Any prose the model wrote around the call is discarded so it cannot claim success.
 */
class AssistantOrchestrator(
    private val tools: ToolRegistry,
    private val executor: ToolExecutor,
    private val models: ModelRunner,
    private val settings: AssistantConfig,
    private val nowText: () -> String = {
        ZonedDateTime.now().format(DateTimeFormatter.ofPattern("EEEE d MMMM yyyy, HH:mm (zzz)"))
    },
) {
    fun handle(userText: String, history: List<ChatTurn>): Flow<AssistantEvent> = flow {
        when (val route = IntentRouter.route(userText)) {
            is RouteOutcome.Command -> {
                emit(prepareTool(route.tool, route.args))
                return@flow
            }
            is RouteOutcome.Clarify -> {
                emit(AssistantEvent.Notice(route.question))
                return@flow
            }
            RouteOutcome.NoMatch -> Unit
        }

        val system = SystemPrompt.build(settings.assistantName, tools.specs(), nowText())
        val prompt = PromptBuilder.build(settings.promptTemplate, system, history, maxChars = settings.maxTokens * 2)
        val reply = StringBuilder()
        try {
            models.use { engine ->
                engine.generate(prompt).collect { chunk ->
                    reply.append(chunk)
                    if (reply.isNotBlank() && !reply.trimStart().startsWith("<")) emit(AssistantEvent.Partial(reply.toString()))
                }
            }
        } catch (e: ModelUnavailableException) {
            emit(
                AssistantEvent.Notice(
                    "${e.message} I can still run device commands such as \"battery\", \"flashlight on\" or \"set a 10 minute timer\".",
                ),
            )
            return@flow
        }

        val raw = reply.toString()
        val call = ToolCallParser.parse(raw)
        if (call != null) {
            emit(prepareTool(call.name, call.args))
            return@flow
        }
        val text = PromptBuilder.cleanOutput(raw)
        emit(if (text.isEmpty()) AssistantEvent.Notice("The model returned an empty response.") else AssistantEvent.Final(text))
    }

    /** Validates a tool call and either runs it, rejects it, or asks the user to confirm it. */
    suspend fun prepareTool(name: String, args: Map<String, String>): AssistantEvent =
        when (val prepared = executor.prepare(name, args)) {
            is ToolExecutor.Prepared.Rejected -> AssistantEvent.ToolOutcome(name, prepared.result)
            is ToolExecutor.Prepared.Ready ->
                if (prepared.tool.spec.requiresConfirmation) {
                    AssistantEvent.NeedsConfirmation(name, prepared.args, prepared.tool.confirmationPrompt(prepared.args))
                } else {
                    AssistantEvent.ToolOutcome(name, executor.run(prepared.tool, prepared.args))
                }
        }

    /** Runs a tool the user has explicitly confirmed. Arguments are re-validated. */
    suspend fun runConfirmed(name: String, args: Map<String, String>): AssistantEvent =
        when (val prepared = executor.prepare(name, args)) {
            is ToolExecutor.Prepared.Rejected -> AssistantEvent.ToolOutcome(name, prepared.result)
            is ToolExecutor.Prepared.Ready -> AssistantEvent.ToolOutcome(name, executor.run(prepared.tool, prepared.args))
        }
}
