# No custom rules yet. Release builds are not configured; debug APK is the supported artifact.
