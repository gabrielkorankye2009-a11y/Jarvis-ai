# Implementation status (honest)

Legend: **Written** = source exists. **Compiled** = a real Gradle build succeeded. **Tested** = an automated test ran
and passed. **On device** = observed working on a phone. Nothing is Compiled, Tested (Kotlin) or On device yet.

| Area | Written | Compiled | Tested | On device | Notes |
|---|---|---|---|---|---|
| Gradle/manifest/resources | yes | no | no | no | Dependency versions are unverified pins; first CI run checks them |
| CI workflows | yes | n/a | n/a | n/a | Never run: no git remote or credentials were available |
| 738-capability registry (JSON + generator) | yes | n/a | **yes (Python)** | n/a | Generator validation and invariants ran and passed; app reads the JSON at runtime (unverified) |
| Registry connected to app (Feature directory screen) | yes | no | no | no | Statuses shown are exactly the registry file's |
| LLM backend (MediaPipe) behind `LlmEngine` | yes | no | no | no | API calls from memory; may not compile as written |
| Model manager (auto-select, fallback, idle unload, benchmark) | yes | no | pure logic written, not run | no | |
| Device-based recommendation | yes | no | written, not run | no | |
| Model import / download | yes | no | no | no | |
| Deterministic command router | yes | no | **regex mirror run in Python (37 cases)**; Kotlin tests written, not run | no | |
| Tool framework, validation, 11 device tools | yes | no | validation/executor tests written, not run | no | Tools need a device |
| Orchestrator (route, model, tool call, confirmation) | yes | no | 10 tests written, not run | no | Uses test doubles for the model |
| Chat storage (Room) + chat UI | yes | no | 4 instrumented tests written, not run | no | |
| Context-aware replies | yes (history sent to model) | no | prompt-assembly tests written, not run | no | Real recall only checked by the E2E test |
| End-to-end with a real model | test written | no | **NOT RUN** | no | Needs a device and a model file |
| Voice (STT/TTS), dashboard, device-control screen, other screens | **no** | | | | Not started in this pass |

## Not done yet
Voice; dashboard; connectivity/offline status centre; memory centre, tasks, calendar, notes; settings screen;
LiteRT-LM and Sherpa-ONNX backends; airplane-mode test; release signing; network activity log.

## Known risks
- The MediaPipe calls and version pin are unverified and are the likeliest compile failure.
- Small models may ignore the tool-call format; the router covers common commands.
- A pending confirmation is lost if the app is killed; its chat message stays marked as waiting.
- `imePadding` plus the bottom bar leaves an extra gap above the keyboard.
