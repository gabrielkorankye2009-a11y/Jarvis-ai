# Implementation Roadmap

Statuses use the registry vocabulary: PLANNED, IN DEVELOPMENT, IMPLEMENTED, TESTED, VERIFIED ON DEVICE, UNAVAILABLE.

| Phase | Scope | Registry domains touched | Status |
|---|---|---|---|
| 1 Foundation | Gradle project, Compose shell, navigation, Room schema, registry loader | 19 (partial), 20 (partial) | IN DEVELOPMENT (written, not yet compiled) |
| 2 AI brain | Model runtime abstraction, MediaPipe backend, model manager, tool-calling engine | 01, 20 | IN DEVELOPMENT (written, not yet compiled or run on a device; LiteRT-LM not integrated) |
| 3 Voice | Sherpa-ONNX STT and TTS, push-to-talk, voice screen | 02 | PLANNED |
| 4 Memory | Persistent memory, retrieval, memory centre | 03, 13 (local) | PLANNED |
| 5 Phone integration | Notifications, alarms, reminders, intents, device control | 06, 07, 08 | PLANNED |
| 6 Productivity | Notes, tasks, files, learning, calendar | 04, 05, 09, 11, 12, 14 | PLANNED |
| 7 Advanced | Vision, document processing, automation, connected devices | 10, 15, 16, 17, 18 | PLANNED |
| 8 Online extensions | Optional research and sync, consent ledger | 13 (online) | PLANNED |
| 9 Optimisation | Battery, thermal, memory, security and offline testing | all | PLANNED |
| 10 Delivery | CI APK build, README, compatibility report | all | PLANNED |

## Phase 1 vertical slice (next)
Text conversation screen, Room persistence, and a model-runtime interface with one real on-device backend. Build and test on an emulator or device; no mock backend is to be presented as a working model.
