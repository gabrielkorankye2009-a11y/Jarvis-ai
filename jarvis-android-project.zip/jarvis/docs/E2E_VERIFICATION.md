# End-to-end verification procedure

**Status: NOT YET RUN.** No end-to-end result exists. The sandbox where this was written could not compile the app,
download a model or run a device. The test below is written so that a passing run on a real phone is meaningful.

## What the test proves when it passes
`LocalModelEndToEndTest` uses the same `ChatViewModel`, `AssistantOrchestrator`, `ModelManager`, MediaPipe engine
and Room database as the app, with a real model file:
1. Sends a message containing a fact ("My name is Ada...") and requires a real, non-empty text reply from the model
   (not a notice, not a raw tool call).
2. Saves the conversation, then **simulates an app restart**: shuts the container down (model unloaded, database
   closed) and builds a second container on the same database file.
3. Checks that the restored history is identical to what was saved.
4. Asks "What is my name?" and requires the reply to contain "Ada". No code path in the app can produce that
   answer except the model reading the restored history. Up to three attempts, because replies are sampled.

It is **skipped, not passed,** if no model is installed. It does not prove reply quality beyond that, speed
targets, tool calling by the model, or airplane-mode operation.

## Steps
1. Get the CI artifacts: push the repository, run the "Android build" workflow, download `jarvis-debug-apk` and
   `jarvis-androidtest-apk`. (Requires the first CI build to succeed; see TESTING_REPORT.md.)
2. `adb install -r app-debug.apk` and `adb install -r app-debug-androidTest.apk`
3. In the app, import a model (docs/MODELS.md) and confirm it loads.
4. Run the test:
   ```
   adb shell am instrument -w -e class com.jarvis.assistant.LocalModelEndToEndTest \
     -e jarvisTemplate GEMMA \
     com.jarvis.assistant.test/androidx.test.runner.AndroidJUnitRunner
   ```
   Use `-e jarvisTemplate CHATML` for Qwen-family models and `-e jarvisModel <file name>` to choose a model.
5. Read the evidence: `adb logcat -d -s JarvisE2E`, and the report file at
   `/sdcard/Android/data/com.jarvis.assistant/files/e2e_report.txt` (device model, RAM, model, both conversations
   verbatim, timings, PASS or FAIL).

The persistence tests (`ChatPersistenceTest`) need no model and can run on an emulator via the manual
"Instrumented tests (emulator)" workflow.

## Result log
| Date | Device | Model | Result | Report |
|---|---|---|---|---|
| (none yet) | | | | |
