# Models: choosing, installing, and what is NOT verified

**Nothing in this file has been verified by running it.** The authoring environment had no network, no Android SDK
and no model file. Model names, sizes, licences and availability below are from memory and MUST be checked on the
model's own page before you rely on them. No model has been loaded by this project yet.

## Runtime
- Backend in the app: **MediaPipe LLM Inference** (`com.google.mediapipe:tasks-genai`), behind the `LlmEngine`
  interface. It loads **`.task`** (and older **`.bin`**) model bundles.
- **`.litertlm` (LiteRT-LM) and GGUF files are not loadable yet.** Adding a backend means implementing `LlmEngine`.
- The exact API calls used (`LlmInferenceOptions.builder`, `createFromOptions`, `generateResponseAsync` with a
  progress listener) were written from memory and are checked only by the first successful CI build.

## How the app picks a model for the device (implemented, unit-tested logic)
`ModelRecommender` reads the device's reported RAM and ABI and maps it to a profile. These are heuristics, not
benchmarks; use the in-app **Run benchmark** button for measured speed.

| Profile | Device (reported RAM) | Suggested model file size | Typical model class |
|---|---|---|---|
| Lite | under 5 GB, or no 64-bit ABI | up to ~30% of RAM | about 0.5 to 1B parameters, 4-bit |
| Balanced | 5 to 9.5 GB | up to ~35% of RAM | about 1 to 2B parameters, 4 or 8-bit |
| Advanced | 9.5 GB and up | up to ~40% of RAM | about 2 to 4B parameters, 4-bit |

Behaviour in `ModelManager`:
- With nothing selected, the **largest installed model that fits the device's suggested size** is chosen automatically.
- A model that can never fit (needs more than ~80% of total RAM) is refused with an explanation; one that exceeds
  the RAM free right now loads with a warning.
- If the selected model fails to load, the app **falls back to the smallest installed model that is lighter**,
  and says so on the Models screen.
- The model is unloaded after 5 minutes of inactivity.

## Candidate models (UNVERIFIED, check each before use)
| Role | Candidate | Prompt format to select | Notes to verify |
|---|---|---|---|
| Lightweight, general | Gemma 3 1B instruction-tuned, 4-bit, MediaPipe `.task` build from the LiteRT community on Hugging Face | Gemma | Gated: you must accept Google's Gemma terms and sign in to download. Size believed to be roughly half a gigabyte or a bit more. |
| Lightweight, no sign-in | Qwen2.5 0.5B Instruct, MediaPipe `.task` build | ChatML | Believed Apache-2.0 for this size; confirm. Weakest at following instructions and at tool calling. |
| Balanced | Qwen2.5 1.5B Instruct `.task` or a Gemma 2B-class `.task` | ChatML or Gemma | Confirm exact files, sizes and licences. |
| Advanced | A 3 to 4B-class `.task` model, only for 12 GB-class phones | match the family | I could not identify one I am confident exists in this format. |

Choose the prompt format on the Models screen to match the model family. A mismatch produces poor or garbled replies.

## Installing a model (the supported path)
1. On a computer or the phone's browser, open the model's page, accept its licence, and download the `.task` file.
2. Open the app, **Models** tab, **Choose file**, and pick the file. It is copied into app-private storage.
3. Tap **Select**, then **Load** (or just send a message; it loads on demand).
4. Pick the matching **prompt format**, then run **Benchmark** to see real speed on your phone.

Alternatively paste a direct `https://` link (no sign-in needed) into **Download from a link**. The app uses the
network only when you tap Download. Many hosts require sign-in; in that case download in a browser and import.

Storage and memory: you need free storage of about the model size plus 200 MB to import, and RAM of roughly 1.2x the
model size to load. If the phone cannot hold the model efficiently, import a smaller one from the Lite row.

## Tool calling with small models
Models of about 1B parameters are unreliable at emitting the `<tool_call>` format. That is why common device commands
("flashlight on", "set a 10 minute timer") go through the deterministic `IntentRouter` first, and only unrecognised
requests reach the model. Anything the model asks a tool to do is validated and executed by the app, and only the
tool's real result is shown. Model prose around a tool call is discarded, but it may flash on screen as streaming
text for a moment before the real result replaces it.

## Offline operation
Inference, chat storage and device tools run on the phone. The network is used only for a model download you start.
This claim is by design and by code inspection; no airplane-mode test has been run yet.
