# Offline Compatibility

Classifications below are PLANNED targets. A capability may be called fully offline only after it passes an airplane-mode test (see TESTING_REPORT.md).

| Class | Meaning | Count |
|---|---|---|
| FULLY_OFFLINE | Works entirely on-device once its assets are installed | 591 |
| LIMITED_OFFLINE | Works offline with reduced function or needs prior data or permission | 62 |
| ONLINE_REQUIRED | Needs internet and, for private data, explicit consent | 9 |
| DEVICE_RESTRICTED | Needs hardware, a permission or system support that may be missing | 76 |

## ONLINE_REQUIRED

- JARVIS-510 Online web search with consent
- JARVIS-511 Online page fetch and summary
- JARVIS-512 Online news briefing
- JARVIS-513 Online fact lookup with source links
- JARVIS-514 Online knowledge-pack update
- JARVIS-516 Import online results into local library
- JARVIS-579 Exchange-rate refresh
- JARVIS-587 Destination weather forecast
- JARVIS-588 Online route directions

## LIMITED_OFFLINE

- JARVIS-007 Translation using local models
- JARVIS-092 Document conversion where supported
- JARVIS-114 Screenshot analysis
- JARVIS-116 Image organisation
- JARVIS-118 Local image search
- JARVIS-161 Downloaded map integration
- JARVIS-167 Navigation handoff to suitable applications
- JARVIS-234 Multilingual recognition with installed language models
- JARVIS-235 Spoken language detection
- JARVIS-236 Multilingual speech output
- JARVIS-241 Speech model download and management
- JARVIS-259 Contact-linked memories
- JARVIS-311 Saved links with titles
- JARVIS-318 Read device calendars
- JARVIS-319 Write device calendar events
- JARVIS-321 Edit event
- JARVIS-322 Delete event with confirmation
- JARVIS-323 Recurring events
- JARVIS-325 All-day events
- JARVIS-326 Multi-day events
- JARVIS-327 Event location field
- JARVIS-329 Daily agenda
- JARVIS-330 Weekly agenda
- JARVIS-331 Next-event query
- JARVIS-332 Free-slot finder
- JARVIS-333 Availability planning
- JARVIS-334 Event conflict detection
- JARVIS-354 Do Not Disturb status read
- JARVIS-371 Contact lookup by name
- JARVIS-372 Fuzzy contact search
- JARVIS-373 Contact search by phone number
- JARVIS-374 Contact detail view
- JARVIS-375 Contact groups listing
- JARVIS-376 Favourite-contact shortcuts
- JARVIS-378 Duplicate contact detection
- JARVIS-381 Birthday extraction from contacts
- JARVIS-402 Message translation with local models
- JARVIS-404 Export contacts to vCard
- JARVIS-405 Import contacts from vCard
- JARVIS-406 Create contact after confirmation
- JARVIS-407 Edit contact after confirmation
- JARVIS-417 Large-file finder
- JARVIS-418 Recent files list
- JARVIS-435 Handwriting recognition
- JARVIS-444 Alt-text generation
- JARVIS-447 Local translation of text in images
- JARVIS-515 Queue questions for when online
- JARVIS-571 Navigation via installed map app (online or downloaded maps)
- JARVIS-572 Offline map file import (format and renderer to be verified)
- JARVIS-573 Downloaded-map availability report
- JARVIS-589 Browse local audio library
- JARVIS-590 Browse local video library
- JARVIS-591 Local media library search
- JARVIS-592 Audio file playback
- JARVIS-593 Video file playback
- JARVIS-604 Music organisation by artist, album and genre
- JARVIS-606 Duplicate track detection
- JARVIS-610 Podcast library from imported audio files
- JARVIS-617 Video folder and tag organisation
- JARVIS-624 Media storage usage report
- JARVIS-670 MQTT broker connection on local network
- JARVIS-671 Home Assistant local API connection with user-supplied URL and token

## DEVICE_RESTRICTED

- JARVIS-066 Flashlight control
- JARVIS-067 Camera launch
- JARVIS-069 Brightness adjustment where authorised
- JARVIS-073 Wi-Fi settings access
- JARVIS-074 Bluetooth settings access
- JARVIS-076 Display settings
- JARVIS-077 Sound settings
- JARVIS-078 Notification settings
- JARVIS-083 Screen orientation where supported
- JARVIS-084 Power-saving settings
- JARVIS-104 Camera integration
- JARVIS-109 Visual question answering where supported
- JARVIS-110 Image descriptions
- JARVIS-111 Scene descriptions
- JARVIS-117 Camera-based document assistance
- JARVIS-157 Location-aware information when authorised
- JARVIS-158 GPS information
- JARVIS-231 Noise suppression pre-processing
- JARVIS-232 Echo cancellation during playback
- JARVIS-233 Automatic gain control
- JARVIS-240 Bluetooth headset audio routing
- JARVIS-339 Create alarm
- JARVIS-340 Repeating alarm days
- JARVIS-341 Show or dismiss alarms via system clock
- JARVIS-355 Do Not Disturb settings handoff
- JARVIS-359 Thermal status read
- JARVIS-365 Screen-timeout settings handoff
- JARVIS-366 Location settings handoff
- JARVIS-384 Place call after explicit confirmation
- JARVIS-385 Call-history read where authorised
- JARVIS-386 Missed-call summary
- JARVIS-387 Frequent-contacts report
- JARVIS-389 Open SMS app with draft pre-filled
- JARVIS-390 Send SMS after explicit confirmation
- JARVIS-395 Open email app with draft pre-filled
- JARVIS-397 Notification-assisted reply drafts
- JARVIS-398 Opt-in notification summaries
- JARVIS-557 Current coordinates read
- JARVIS-558 Approximate location read
- JARVIS-559 GPS availability status
- JARVIS-560 GPS accuracy and satellite count
- JARVIS-561 Altitude and speed read
- JARVIS-562 Save current place with label
- JARVIS-565 Compass heading
- JARVIS-566 Bearing to a saved place
- JARVIS-567 Barometric pressure reading
- JARVIS-586 Visited-places log
- JARVIS-614 Control other media apps through media sessions
- JARVIS-615 Now-playing information read
- JARVIS-626 Equalizer presets
- JARVIS-641 Step count from device sensor
- JARVIS-655 Bluetooth device scan with permission
- JARVIS-656 Paired Bluetooth device list
- JARVIS-657 BLE device connection
- JARVIS-658 BLE service discovery
- JARVIS-659 BLE characteristic read
- JARVIS-660 BLE characteristic write after confirmation
- JARVIS-661 BLE notification subscription
- JARVIS-662 Heart-rate monitor reading via standard BLE profile
- JARVIS-663 BLE device battery level via standard service
- JARVIS-664 Environmental sensor reading via standard BLE service
- JARVIS-665 Smart-light control for supported BLE models
- JARVIS-666 Smart-plug control over local network for supported protocols
- JARVIS-667 Local-network discovery with mDNS
- JARVIS-668 UPnP and SSDP discovery
- JARVIS-669 Matter support feasibility assessment
- JARVIS-672 Device status dashboard
- JARVIS-675 Saved scenes
- JARVIS-676 Time-based device automation
- JARVIS-677 Sunset-triggered device automation
- JARVIS-678 Low-battery alerts for connected devices
- JARVIS-679 Device offline detection
- JARVIS-682 Sensor logging to local database
- JARVIS-684 Phone sensor readings for light, proximity and motion
- JARVIS-685 Wi-Fi network information read
- JARVIS-691 Voice control of connected devices
