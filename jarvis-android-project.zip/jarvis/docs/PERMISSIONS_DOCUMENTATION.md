# Permissions Documentation

Principle: request a permission only when the first feature that needs it is used, explain why, and degrade gracefully on denial.
Special-access permissions (exact alarms, notification listener, write settings) are opened through system screens, never bypassed.

| Permission | Capabilities needing it | Example capabilities |
|---|---|---|
| ACCESS_COARSE_LOCATION | 2 | Location-aware information when authorised; Approximate location read |
| ACCESS_FINE_LOCATION | 8 | GPS information; Current coordinates read; GPS availability status |
| ACCESS_NETWORK_STATE | 1 | Available network information |
| ACCESS_NOTIFICATION_POLICY | 1 | Do Not Disturb status read |
| ACCESS_WIFI_STATE | 1 | Wi-Fi network information read |
| ACTIVITY_RECOGNITION | 1 | Step count from device sensor |
| BIND_NOTIFICATION_LISTENER_SERVICE | 4 | Notification-assisted reply drafts; Opt-in notification summaries; Control other media apps through media sessions |
| BLUETOOTH_CONNECT | 11 | Bluetooth headset audio routing; Paired Bluetooth device list; BLE device connection |
| BLUETOOTH_SCAN | 1 | Bluetooth device scan with permission |
| CALL_PHONE | 1 | Place call after explicit confirmation |
| CAMERA | 11 | Camera integration; Document scanning; Camera-based document assistance |
| CHANGE_WIFI_MULTICAST_STATE | 2 | Local-network discovery with mDNS; UPnP and SSDP discovery |
| FOREGROUND_SERVICE_MICROPHONE | 1 | Optional wake-phrase detection |
| INTERNET | 15 | Speech model download and management; Online web search with consent; Online page fetch and summary |
| POST_NOTIFICATIONS | 16 | Persistent listening indicator; Task reminders with exact alarms; Reminder snooze |
| READ_CALENDAR | 7 | Read device calendars; Daily agenda; Weekly agenda |
| READ_CALL_LOG | 3 | Call-history read where authorised; Missed-call summary; Frequent-contacts report |
| READ_CONTACTS | 10 | Contact-linked memories; Contact lookup by name; Fuzzy contact search |
| READ_MEDIA_AUDIO | 7 | Browse local audio library; Local media library search; Audio file playback |
| READ_MEDIA_IMAGES | 5 | Screenshot analysis; Image organisation; Local image search |
| READ_MEDIA_VIDEO | 5 | Browse local video library; Local media library search; Video file playback |
| RECORD_AUDIO | 29 | Offline speech-to-text; Streaming partial transcription; Voice activity detection |
| SCHEDULE_EXACT_ALARM | 3 | Task reminders with exact alarms; Event reminders; Scheduled workflow run |
| SEND_SMS | 1 | Send SMS after explicit confirmation |
| SET_ALARM | 3 | Create alarm; Repeating alarm days; Show or dismiss alarms via system clock |
| VIBRATE | 1 | Vibration feedback control |
| WRITE_CALENDAR | 7 | Write device calendar events; Edit event; Delete event with confirmation |
| WRITE_CONTACTS | 3 | Import contacts from vCard; Create contact after confirmation; Edit contact after confirmation |
| WRITE_SETTINGS | 1 | Brightness adjustment where authorised |
