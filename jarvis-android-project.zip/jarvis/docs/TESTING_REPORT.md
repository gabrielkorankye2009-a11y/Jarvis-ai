# Testing Report

Last updated: 2026-11-09. This file records only tests that were actually executed.

## Environment used so far
Linux sandbox, OpenJDK 21, Python 3, 1 CPU, ~4 GB RAM, no network. No Android SDK, Gradle, Kotlin compiler, emulator or physical device available.

## Results
| Test | Result | Notes |
|---|---|---|
| Registry validation (`tools/registry/build_registry.py`) | PASS | 738 entries, 30+ per domain (min 30, domain 01), unique IDs and names, all offline classes valid |
| Android project compilation | NOT RUN | No Android SDK or Gradle in the build environment |
| Unit tests | NOT RUN | No Kotlin code has been compiled yet |
| First install, startup, model loading, conversations | NOT RUN | Need a device or emulator |
| Voice recognition and speech generation | NOT RUN | Phase 3 |
| Memory, notes, tasks, reminders | NOT RUN | Phases 4 to 6 |
| Airplane-mode test | NOT RUN | Needs a device or emulator |

## Known limitations of the registry
- Descriptions are short placeholders (name plus domain); they need rewriting as each capability is implemented.
- Acceptance tests are templated by offline class; each must be made specific when its capability is built.
- Offline classes and Android APIs are design targets. Library choices marked "to be verified" or "TBD" have not been checked against current documentation because the sandbox has no network.

## Update: audit and engine pass
Audit findings (all verified by command, not assumed):
- Before this pass there were **zero Kotlin files** and the manifest named two classes that did not exist. 32 registry entries were wrongly marked IN DEVELOPMENT and were reverted; statuses are now derived from code that exists.
- The sandbox has no Android SDK, Gradle, Kotlin compiler, adb, emulator, language-model file or network, and no git remote, GitHub CLI or credentials.

What was actually executed in this pass:
| Check | Result |
|---|---|
| Registry generator and validation (`tools/registry/build_registry.py`) | PASS: 738 entries, 20 domains, min 30 per domain, unique IDs and names |
| Registry invariants vs `ToolSpecs.kt` (Python re-implementation of `CapabilityRegistryFileTest`) | PASS: 19 tool-backed + 6 non-tool names are exactly the 25 non-PLANNED entries; all NOT_TESTED |
| Config static checks: TOML parse, Gradle aliases resolve, manifest XML well-formed, workflow YAML parses | PASS; manifest classes now exist |
| Router regex mirror (`tools/checks/router_regex_mirror.py`, 37 cases) | PASS. Mirrors the Kotlin patterns; does not execute Kotlin |
| Kotlin smoke check (`tools/checks/static_kotlin_check.py`, 39 files) | PASS: packages, imports and brackets only. **Not compilation** |

Written but NOT run (no Kotlin toolchain): 56 JVM unit tests in 9 files, 5 instrumented tests in 2 files
(including the real-model end-to-end test). Gradle build: **NOT RUN**. CI: **NOT RUN**. APK: **does not exist**.
GitHub push and Actions trigger: **not possible from this environment.**
