#!/usr/bin/env python3
"""Smoke check for Kotlin sources. NOT a compiler: it cannot find type errors, missing members or API mistakes.
Checks: package matches directory, brackets balance, and every com.jarvis.assistant import resolves to a declared name."""
import os, re, sys

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
files = []
for base, _, names in os.walk(os.path.join(ROOT, "app", "src")):
    files += [os.path.join(base, n) for n in names if n.endswith(".kt")]

def strip(src):
    out, i, n = [], 0, len(src)
    while i < n:
        if src.startswith('"""', i):
            j = src.find('"""', i + 3); i = n if j < 0 else j + 3; out.append('""'); continue
        if src.startswith('//', i):
            j = src.find('\n', i); i = n if j < 0 else j; continue
        if src.startswith('/*', i):
            j = src.find('*/', i + 2); i = n if j < 0 else j + 2; continue
        c = src[i]
        if c == '"':
            i += 1
            while i < n and src[i] != '"':
                i += 2 if src[i] == '\\' else 1
            i += 1; out.append('""'); continue
        if c == "'":
            j = i + 1
            while j < n and src[j] != "'":
                j += 2 if src[j] == '\\' else 1
            i = j + 1; out.append("''"); continue
        out.append(c); i += 1
    return "".join(out)

decl = re.compile(r'\b(?:class|interface|object|fun|val|var|typealias)\s+(?:<[^>]*>\s*)?(?:[A-Za-z_][A-Za-z0-9_<>?., ]*\.)?([A-Za-z_][A-Za-z0-9_]*)')
pkg_names, pkgs, problems = {}, {}, []
for f in files:
    raw = open(f, encoding="utf-8").read()
    m = re.search(r'^package\s+([\w.]+)', raw, re.M)
    if not m:
        problems.append(f"{f}: no package line"); continue
    p = m.group(1); pkgs[f] = p
    rel = os.path.relpath(os.path.dirname(f), ROOT).replace(os.sep, "/")
    if not rel.endswith(p.replace(".", "/")):
        problems.append(f"{os.path.relpath(f, ROOT)}: package {p} does not match its directory")
    s = strip(raw)
    pkg_names.setdefault(p, set()).update(decl.findall(s))
    for o, c in ("()", "{}", "[]"):
        if s.count(o) != s.count(c):
            problems.append(f"{os.path.relpath(f, ROOT)}: unbalanced {o}{c} ({s.count(o)} vs {s.count(c)})")

known = set(pkg_names)
for f in files:
    for imp in re.findall(r'^import\s+([\w.]+)', open(f, encoding="utf-8").read(), re.M):
        if not imp.startswith("com.jarvis.assistant"):
            continue
        parts = imp.split(".")
        for k in range(len(parts) - 1, 0, -1):
            pk = ".".join(parts[:k])
            if pk in known:
                if parts[k] not in pkg_names[pk]:
                    problems.append(f"{os.path.relpath(f, ROOT)}: import {imp} -> '{parts[k]}' not declared in {pk}")
                break
        else:
            problems.append(f"{os.path.relpath(f, ROOT)}: import {imp} matches no package")

print(f"kotlin files checked: {len(files)}")
if problems:
    print("PROBLEMS:"); [print(" -", x) for x in problems]; sys.exit(1)
print("smoke check passed (this is not compilation)")
