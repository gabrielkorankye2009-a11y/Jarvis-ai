# Python MIRROR of the Kotlin IntentRouter regexes. It checks the patterns on the JVM-compatible regex subset;
# it does NOT execute the Kotlin code. The authoritative test is app/src/test/.../IntentRouterTest.kt.
import re
I=re.IGNORECASE
PREFIX=re.compile(r"^(?:(?:please|hey|ok|okay|jarvis|j\.a\.r\.v\.i\.s\.?)[,:]?\s+)+",I)
SUFFIX=re.compile(r"(?:,?\s*please)?[.!?\s]*$",I)
def clean(s): return SUFFIX.sub("",PREFIX.sub("",s.strip())).strip()
CLIP=re.compile(r"^copy\s+(.+?)\s+to\s+(?:the\s+|my\s+)?clipboard$",I)
SETT=re.compile(r"\b(wi-?fi|bluetooth|display|sound|battery saver|power saving|location|notification)s?\s+settings?\b",I)
SETVERB=re.compile(r"^(?:open|show|go to|take me to|launch|bring up)\b",I)
Q=re.compile(r"^(?:what|how|why|explain|tell|when|who)\b",I)
DUR=re.compile(r"(\d+(?:\.\d+)?)\s*-?\s*(hours?|hrs?|minutes?|mins?|seconds?|secs?)\b",I)
AN=re.compile(r"\b(half an hour|an hour|a minute|a second)\b",I)
ALARMW=re.compile(r"\balarm\b|\bwake me\b",I)
ATIME=re.compile(r"(?:\b(?:at|for)\s+|\balarm\s+)(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)?(?![\w:])",I)
FLASH=re.compile(r"^(?:turn|switch|put|set|enable|disable|toggle)\b.*\b(?:flash ?light|torch)\b|^(?:the\s+)?(?:flash ?light|torch)\s+(?:on|off)\b",I)
VOLCMD=re.compile(r"^(?:set|turn|change|make|adjust|put|lower|raise|increase|decrease|volume)\b",I)
VOLNUM=re.compile(r"\b(?:to|at)\s+(\d{1,3})\s*(?:%|percent)?(?![\w])|\b(\d{1,3})\s*(?:%|percent)",I)
OPEN=re.compile(r"^(?:open|launch|start|run)\s+(?:the\s+)?(.+?)(?:\s+app(?:lication)?)?$",I)
def words(s): return len(s.split())
def route(inp):
    t=clean(inp)
    m=CLIP.match(t)
    if m: return ("clipboard_copy",{"text":m.group(1)})
    m=SETT.search(t)
    if m and (SETVERB.match(t) or words(t)<=4):
        k=m.group(1).lower()
        scr={"wifi":"wifi","wi-fi":"wifi","bluetooth":"bluetooth","display":"display","sound":"sound","battery saver":"battery_saver","power saving":"battery_saver","location":"location","notification":"notifications"}[k]
        return ("open_settings",{"screen":scr})
    if re.search(r"\btimer\b",t,I) and not Q.match(t):
        secs=0.0; found=False
        for d in DUR.finditer(t):
            found=True; u=d.group(2).lower(); v=float(d.group(1))
            secs+=v*(3600 if u.startswith("h") else 60 if u.startswith("m") else 1)
        for a in AN.finditer(t):
            found=True; w=a.group(1).lower()
            secs+={"half an hour":1800,"an hour":3600,"a minute":60,"a second":1}[w]
        if not found: return ("clarify","How long should the timer run?")
        return ("set_timer",{"seconds":str(round(secs))})
    if ALARMW.search(t) and not Q.match(t):
        m=ATIME.search(t)
        if not m: return ("clarify","What time should the alarm ring?")
        h=int(m.group(1)); mi=int(m.group(2)) if m.group(2) else 0; mer=(m.group(3) or "").replace(".","").lower()
        if h>23 or mi>59: return ("clarify","I didn't understand that time. Try something like 7:30 AM.")
        if mer:
            if h>12 or h==0: return ("clarify","That time mixes 24-hour and AM/PM. Which do you mean?")
            h=(0 if h==12 else h)+(12 if mer=="pm" else 0)
        elif 1<=h<=12:
            return ("clarify",f"Do you mean {h}:{mi:02d} AM or PM?")
        return ("set_alarm",{"hour":str(h),"minute":str(mi)})
    if FLASH.search(t):
        if re.search(r"\boff\b|\bdisable\b",t,I): return ("flashlight",{"state":"off"})
        if re.search(r"\bon\b|\benable\b",t,I): return ("flashlight",{"state":"on"})
        return ("clarify","Do you want the flashlight on or off?")
    if re.search(r"\bvolume\b",t,I) and VOLCMD.match(t):
        m=VOLNUM.search(t)
        if not m: return ("clarify","What volume level, from 0 to 100 percent?")
        return ("set_volume",{"percent":m.group(1) or m.group(2)})
    w=words(t)
    if re.search(r"\bbattery\b",t,I) and w<=8 and not re.search(r"\b(saver|settings?)\b",t,I): return ("device_battery",{})
    if re.search(r"\b(storage|free space|disk space)\b",t,I) and w<=8: return ("device_storage",{})
    if re.search(r"\b(device info(?:rmation)?|phone info(?:rmation)?|about (?:my|this) (?:phone|device)|which phone|what phone)\b",t,I) and w<=8: return ("device_info",{})
    if re.search(r"\b(airplane mode|flight mode|am i (?:online|connected)|internet connection|network status|connectivity|is (?:the )?internet)\b",t,I) and w<=10: return ("network_status",{})
    m=OPEN.match(t)
    if m:
        name=re.sub(r"^my\s+","",m.group(1).strip(),flags=I)
        if words(name)<=4 and not re.match(r"^(?:a|an)\s",name,I) and not re.search(r"\b(timer|alarm|settings?)\b",name,I):
            return ("open_app",{"app_name":name})
    return None
cases=[
("Turn on the flashlight",("flashlight",{"state":"on"})),
("turn the torch off please",("flashlight",{"state":"off"})),
("flashlight on",("flashlight",{"state":"on"})),
("Turn the flashlight",("clarify","Do you want the flashlight on or off?")),
("how does a flashlight work",None),
("What's my battery level?",("device_battery",{})),
("open battery saver settings",("open_settings",{"screen":"battery_saver"})),
("write a poem about my dying battery and my feelings about it today",None),
("how much storage do I have",("device_storage",{})),
("Start a 20 minute timer",("set_timer",{"seconds":"1200"})),
("set a timer for 1 hour 30 minutes",("set_timer",{"seconds":"5400"})),
("20-minute timer",("set_timer",{"seconds":"1200"})),
("start a timer",("clarify","How long should the timer run?")),
("set a timer for half an hour",("set_timer",{"seconds":"1800"})),
("set a timer for 1.5 hours",("set_timer",{"seconds":"5400"})),
("how do timers work in swift",None),
("Set an alarm for 7 pm",("set_alarm",{"hour":"19","minute":"0"})),
("wake me up at 6:15 am",("set_alarm",{"hour":"6","minute":"15"})),
("set an alarm for 7",("clarify","Do you mean 7:00 AM or PM?")),
("set an alarm for 19:30",("set_alarm",{"hour":"19","minute":"30"})),
("set alarm for 12 am",("set_alarm",{"hour":"0","minute":"0"})),
("set an alarm",("clarify","What time should the alarm ring?")),
("set volume to 40 percent",("set_volume",{"percent":"40"})),
("turn the volume up",("clarify","What volume level, from 0 to 100 percent?")),
("make the volume 30%",("set_volume",{"percent":"30"})),
("open wifi settings",("open_settings",{"screen":"wifi"})),
("bluetooth settings",("open_settings",{"screen":"bluetooth"})),
("open WhatsApp",("open_app",{"app_name":"WhatsApp"})),
("launch the camera app",("open_app",{"app_name":"camera"})),
("open my notes",("open_app",{"app_name":"notes"})),
("start a conversation about biology",None),
("copy hello world to the clipboard",("clipboard_copy",{"text":"hello world"})),
("am I online?",("network_status",{})),
("is airplane mode on",("network_status",{})),
("about my phone",("device_info",{})),
("tell me a joke",None),
("Jarvis, please open Maps",("open_app",{"app_name":"Maps"})),
]
bad=0
for inp,exp in cases:
    got=route(inp)
    if got!=exp:
        bad+=1; print("MISMATCH",repr(inp),"got",got,"expected",exp)
print("cases",len(cases),"mismatches",bad)
