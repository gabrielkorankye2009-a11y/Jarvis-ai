#!/usr/bin/env python3
"""Build the J.A.R.V.I.S. capability registry and validate it.

Inputs : spec_seed.json (capabilities named verbatim in the master prompt)
         supplement_*.txt (additional capabilities authored to reach 30+ per domain)
Outputs: ../../app/src/main/assets/capability_registry.json
         ../../docs/FEATURE_CATALOG.md, OFFLINE_COMPATIBILITY.md, PERMISSIONS_DOCUMENTATION.md
Every entry starts as PLANNED / NOT TESTED. This script never promotes a status.
"""
import json, glob, os, re, sys, collections

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))
OFFLINE = {"F": "FULLY_OFFLINE", "L": "LIMITED_OFFLINE", "N": "ONLINE_REQUIRED", "D": "DEVICE_RESTRICTED"}

# domain -> (module, default offline class, default permissions, default APIs)
DOMAINS = {
    "01": ("conversation", "F", "-", "Local LLM, Room"),
    "02": ("voice", "F", "RECORD_AUDIO", "Sherpa-ONNX"),
    "03": ("memory", "F", "-", "Room"),
    "04": ("tasks", "F", "-", "Room"),
    "05": ("knowledge", "F", "-", "Room FTS"),
    "06": ("calendar", "F", "-", "java.time"),
    "07": ("device", "F", "-", "Android platform APIs"),
    "08": ("communication", "L", "READ_CONTACTS", "ContactsContract"),
    "09": ("files", "F", "-", "Storage Access Framework"),
    "10": ("vision", "F", "-", "On-device vision"),
    "11": ("education", "F", "-", "Local LLM, Room"),
    "12": ("writing", "F", "-", "Local LLM"),
    "13": ("research", "F", "-", "Room, Local LLM"),
    "14": ("workflows", "F", "-", "Room, WorkManager"),
    "15": ("location", "F", "-", "Room"),
    "16": ("media", "L", "-", "MediaStore, Media3"),
    "17": ("wellness", "F", "-", "Room"),
    "18": ("smarthome", "D", "-", "Bluetooth and local network APIs"),
    "19": ("privacy", "F", "-", "Android Keystore, Room"),
    "20": ("developer", "F", "-", "Local LLM, Kotlin"),
}

# Overrides for capabilities named verbatim in the spec: name -> (offline, perms, apis)
OVERRIDES = {
    "Translation using local models": ("L", "-", "Local LLM"),
    "Flashlight control": ("D", "-", "CameraManager.setTorchMode"),
    "Camera launch": ("D", "-", "MediaStore.ACTION_IMAGE_CAPTURE"),
    "Volume adjustment": ("F", "-", "AudioManager"),
    "Brightness adjustment where authorised": ("D", "WRITE_SETTINGS", "Settings.System.SCREEN_BRIGHTNESS"),
    "Battery information": ("F", "-", "BatteryManager"),
    "Storage information": ("F", "-", "StatFs, StorageStatsManager"),
    "Device diagnostics": ("F", "-", "Build, ActivityManager, BatteryManager"),
    "Wi-Fi settings access": ("D", "-", "Settings.ACTION_WIFI_SETTINGS"),
    "Bluetooth settings access": ("D", "-", "Settings.ACTION_BLUETOOTH_SETTINGS"),
    "Airplane-mode status": ("F", "-", "Settings.Global.AIRPLANE_MODE_ON"),
    "Display settings": ("D", "-", "Settings.ACTION_DISPLAY_SETTINGS"),
    "Sound settings": ("D", "-", "Settings.ACTION_SOUND_SETTINGS"),
    "Notification settings": ("D", "-", "Settings.ACTION_APP_NOTIFICATION_SETTINGS"),
    "Opening applications": ("F", "-", "PackageManager.getLaunchIntentForPackage"),
    "Managing assistant preferences": ("F", "-", "DataStore"),
    "Clipboard operations with appropriate user consent": ("F", "-", "ClipboardManager"),
    "Device information": ("F", "-", "Build"),
    "Screen orientation where supported": ("D", "-", "Activity.requestedOrientation (own app only)"),
    "Power-saving settings": ("D", "-", "Settings.ACTION_BATTERY_SAVER_SETTINGS"),
    "Available network information": ("F", "ACCESS_NETWORK_STATE", "ConnectivityManager"),
    "Document conversion where supported": ("L", "-", "Storage Access Framework, converters TBD"),
    "Image-to-text processing": ("F", "-", "On-device text recognition"),
    "Camera integration": ("D", "CAMERA", "CameraX"),
    "Document scanning": ("F", "CAMERA", "CameraX, image processing"),
    "Visual question answering where supported": ("D", "-", "On-device multimodal model (device dependent)"),
    "Image descriptions": ("D", "-", "On-device multimodal model (device dependent)"),
    "Scene descriptions": ("D", "-", "On-device multimodal model (device dependent)"),
    "Local image search": ("L", "READ_MEDIA_IMAGES", "MediaStore, embeddings"),
    "Image organisation": ("L", "READ_MEDIA_IMAGES", "MediaStore"),
    "Camera-based document assistance": ("D", "CAMERA", "CameraX, text recognition"),
    "Screenshot analysis": ("L", "READ_MEDIA_IMAGES", "MediaStore, text recognition"),
    "Location-aware information when authorised": ("D", "ACCESS_COARSE_LOCATION", "LocationManager"),
    "GPS information": ("D", "ACCESS_FINE_LOCATION", "LocationManager, GnssStatus"),
    "Downloaded map integration": ("L", "-", "SAF, map renderer TBD"),
    "Time-zone information": ("F", "-", "java.time"),
    "Navigation handoff to suitable applications": ("L", "-", "Intent.ACTION_VIEW geo"),
    "App lock integration": ("F", "-", "BiometricPrompt"),
    "Network activity transparency": ("F", "-", "Network policy, Room"),
}

# Spec names that appear in more than one domain; rename to keep every entry distinct.
RENAMES = {
    ("12", "Summarisation"): "Summarisation of drafts and sources",
    ("12", "Brainstorming"): "Creative brainstorming",
    ("12", "Editing"): "Structural editing",
    ("11", "Concept comparison"): "Study concept comparison",
    ("12", "Debate preparation"): "Debate case preparation",
    ("13", "Information comparison"): "Information comparison across sources",
    ("14", "Checklists"): "Productivity checklists",
    ("09", "Document summaries"): "Per-file document summaries",
}

ACCEPTANCE = {
    "F": "Airplane mode on, required assets already installed: invoke '{n}'; verify it completes, the result is persisted or shown, and the network log records zero requests.",
    "L": "Airplane mode on: invoke '{n}'; verify the offline part works with its required data or permission present, and that the missing-permission or missing-data case is reported honestly rather than faked.",
    "N": "Airplane mode on: verify '{n}' is shown as ONLINE REQUIRED and does not fabricate output. Network on with consent: verify the result is labelled as online-sourced and the consent ledger records the request.",
    "D": "On a device that supports it: verify '{n}' succeeds or opens the correct system screen and reports the real outcome. Where hardware, permission or system support is absent: verify DEVICE RESTRICTED is displayed.",
}


def slug(s):
    return re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()


def load():
    seed = json.load(open(os.path.join(HERE, "spec_seed.json"), encoding="utf-8"))
    entries = []
    for dom in sorted(DOMAINS):
        module, o, perms, apis = DOMAINS[dom]
        for name in seed[dom]["seed"]:
            name = RENAMES.get((dom, name), name)
            oo, pp, aa = OVERRIDES.get(name, OVERRIDES.get(name, (o, perms, apis)))
            entries.append(dict(domain=dom, name=name, offline=oo, perms=pp, apis=aa, origin="spec"))
    for path in sorted(glob.glob(os.path.join(HERE, "supplement_*.txt"))):
        for line in open(path, encoding="utf-8"):
            line = line.rstrip("\n")
            if not line or line.startswith("#"):
                continue
            p = line.split("|")
            if len(p) != 5:
                sys.exit(f"Malformed line in {os.path.basename(path)}: {line}")
            dom, name, oo, pp, aa = p
            name = RENAMES.get((dom, name), name)
            entries.append(dict(domain=dom, name=name, offline=oo, perms=pp, apis=aa or DOMAINS[dom][3], origin="authored"))
    return seed, entries


def validate(seed, entries):
    problems = []
    by_dom = collections.Counter(e["domain"] for e in entries)
    for d in DOMAINS:
        if by_dom[d] < 30:
            problems.append(f"Domain {d} has {by_dom[d]} entries (<30)")
    seen = {}
    for e in entries:
        k = slug(e["name"])
        if k in seen:
            problems.append(f"Duplicate name '{e['name']}' in domains {seen[k]} and {e['domain']}")
        seen[k] = e["domain"]
        if e["offline"] not in OFFLINE:
            problems.append(f"Bad offline class for {e['name']}: {e['offline']}")
    if len(entries) < 600:
        problems.append(f"Total {len(entries)} < 600")
    return by_dom, problems


STATUSES = {"PLANNED", "IN DEVELOPMENT", "IMPLEMENTED", "TESTED", "VERIFIED ON DEVICE", "UNAVAILABLE"}


def load_status_overrides(entries):
    names = {slug(e["name"]): e["name"] for e in entries}
    out, problems = {}, []
    for line in open(os.path.join(HERE, "status_overrides.txt"), encoding="utf-8"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        name, _, status = line.partition("|")
        if slug(name) not in names:
            problems.append(f"status_overrides.txt names unknown capability '{name}'")
        elif status not in STATUSES:
            problems.append(f"status_overrides.txt has bad status '{status}' for '{name}'")
        else:
            out[names[slug(name)]] = status
    return out, problems


def main():
    seed, entries = load()
    by_dom, problems = validate(seed, entries)
    print("Per-domain counts:", dict(sorted(by_dom.items())))
    print("Total entries:", len(entries))
    overrides, op = load_status_overrides(entries)
    problems += op
    if problems:
        print("VALIDATION FAILED:")
        for p in problems:
            print(" -", p)
        sys.exit(1)

    registry = []
    for i, e in enumerate(entries, 1):
        dom = e["domain"]
        registry.append({
            "id": f"JARVIS-{i:03d}",
            "name": e["name"],
            "domain": dom,
            "domainTitle": seed[dom]["title"],
            "module": DOMAINS[dom][0],
            "description": f"{e['name']} ({seed[dom]['title'].title()}).",
            "permissions": [] if e["perms"] == "-" else [x.strip() for x in e["perms"].split(",")],
            "offlineClass": OFFLINE[e["offline"]],
            "androidApis": e["apis"],
            "implementationStatus": overrides.get(e["name"], "PLANNED"),
            "testingStatus": "NOT_TESTED",
            "acceptanceTest": ACCEPTANCE[e["offline"]].format(n=e["name"]),
            "origin": e["origin"],
        })

    assets = os.path.join(ROOT, "app", "src", "main", "assets")
    docs = os.path.join(ROOT, "docs")
    os.makedirs(assets, exist_ok=True)
    os.makedirs(docs, exist_ok=True)
    json.dump({"schemaVersion": 1, "count": len(registry), "capabilities": registry},
              open(os.path.join(assets, "capability_registry.json"), "w", encoding="utf-8"), indent=1, ensure_ascii=False)

    def esc(s):
        return str(s).replace("|", "\\|")

    # FEATURE_CATALOG.md
    st = collections.Counter(r["implementationStatus"] for r in registry)
    out = ["# Feature Catalog", "",
           f"{len(registry)} capabilities across 20 domains. Generated by `tools/registry/build_registry.py` from the spec, supplement files and `status_overrides.txt`; do not edit by hand.",
           "Status counts: " + ", ".join(f"{k}: {v}" for k, v in sorted(st.items())) + ". No capability is TESTED or VERIFIED ON DEVICE yet.",
           "IN DEVELOPMENT means code exists but has not been compiled or tested by CI. Offline classes are design targets, not results.", ""]
    for dom in sorted(DOMAINS):
        rows = [r for r in registry if r["domain"] == dom]
        out += [f"## Domain {dom}: {seed[dom]['title']} ({len(rows)})", "",
                "| ID | Capability | Offline class | Permissions | Android APIs | Status |", "|---|---|---|---|---|---|"]
        for r in rows:
            out.append(f"| {r['id']} | {esc(r['name'])} | {r['offlineClass']} | {esc(', '.join(r['permissions']) or '-')} | {esc(r['androidApis'])} | {r['implementationStatus']} |")
        out.append("")
    open(os.path.join(docs, "FEATURE_CATALOG.md"), "w", encoding="utf-8").write("\n".join(out))

    # OFFLINE_COMPATIBILITY.md
    cls = collections.Counter(r["offlineClass"] for r in registry)
    out = ["# Offline Compatibility", "",
           "Classifications below are PLANNED targets. A capability may be called fully offline only after it passes an airplane-mode test (see TESTING_REPORT.md).", "",
           "| Class | Meaning | Count |", "|---|---|---|",
           f"| FULLY_OFFLINE | Works entirely on-device once its assets are installed | {cls['FULLY_OFFLINE']} |",
           f"| LIMITED_OFFLINE | Works offline with reduced function or needs prior data or permission | {cls['LIMITED_OFFLINE']} |",
           f"| ONLINE_REQUIRED | Needs internet and, for private data, explicit consent | {cls['ONLINE_REQUIRED']} |",
           f"| DEVICE_RESTRICTED | Needs hardware, a permission or system support that may be missing | {cls['DEVICE_RESTRICTED']} |", ""]
    for c in ("ONLINE_REQUIRED", "LIMITED_OFFLINE", "DEVICE_RESTRICTED"):
        out += [f"## {c}", ""]
        out += [f"- {r['id']} {r['name']}" for r in registry if r["offlineClass"] == c]
        out.append("")
    open(os.path.join(docs, "OFFLINE_COMPATIBILITY.md"), "w", encoding="utf-8").write("\n".join(out))

    # PERMISSIONS_DOCUMENTATION.md
    perm = collections.defaultdict(list)
    for r in registry:
        for p in r["permissions"]:
            perm[p].append(r)
    out = ["# Permissions Documentation", "",
           "Principle: request a permission only when the first feature that needs it is used, explain why, and degrade gracefully on denial.",
           "Special-access permissions (exact alarms, notification listener, write settings) are opened through system screens, never bypassed.", "",
           "| Permission | Capabilities needing it | Example capabilities |", "|---|---|---|"]
    for p in sorted(perm):
        ex = "; ".join(r["name"] for r in perm[p][:3])
        out.append(f"| {p} | {len(perm[p])} | {esc(ex)} |")
    open(os.path.join(docs, "PERMISSIONS_DOCUMENTATION.md"), "w", encoding="utf-8").write("\n".join(out) + "\n")

    print("Statuses:", dict(collections.Counter(r["implementationStatus"] for r in registry)))
    print("Offline classes:", dict(cls))
    print("Distinct permissions referenced:", len(perm))
    print("Registry written. Validation passed.")


if __name__ == "__main__":
    main()
